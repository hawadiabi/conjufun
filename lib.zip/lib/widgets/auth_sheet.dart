import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../main.dart' show brandBlue, brandYellow;
import '../data/app_db.dart';

enum _AuthMode { login, signup }

// --- Ouvre la fenêtre de connexion ---
Future<bool?> showLoginSheet(BuildContext context) {
  return showAuthSheet(context);
}

// --- Ouvre la fenêtre d'inscription ---
Future<bool?> showSignupSheet(BuildContext context) {
  return showAuthSheet(context, mode: _AuthMode.signup);
}

// --- Fenêtre centrale ---
Future<bool?> showAuthSheet(
  BuildContext context, {
  _AuthMode mode = _AuthMode.login,
}) {
  return showDialog<bool>(
    context: context,
    barrierDismissible: false,
    builder: (ctx) => AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      contentPadding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      content: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 380),
        child: _AuthSheetBody(initialMode: mode),
      ),
    ),
  );
}

class _AuthSheetBody extends StatefulWidget {
  const _AuthSheetBody({required this.initialMode});
  final _AuthMode initialMode;

  @override
  State<_AuthSheetBody> createState() => _AuthSheetBodyState();
}

class _AuthSheetBodyState extends State<_AuthSheetBody> {
  final _nameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _confirmCtrl = TextEditingController();

  final _formKey = GlobalKey<FormState>();
  bool _loading = false;
  String? _error;
  late _AuthMode _mode;

  @override
  void initState() {
    super.initState();
    _mode = widget.initialMode;
  }

  String _randomSalt(int len) {
    const chars =
        'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    final r = Random.secure();
    return List.generate(len, (_) => chars[r.nextInt(chars.length)]).join();
  }

  Future<void> _doLogin() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final email = _emailCtrl.text.trim().toLowerCase();
      final pass = _passCtrl.text;

      final user = await AppDb.instance.getUserByEmail(email);
      if (user == null) {
        setState(() => _error = "Compte introuvable.");
        return;
      }

      final salt = (user['salt'] as String?) ?? '';
      final hash = sha256.convert(utf8.encode('$salt$pass')).toString();
      if (hash != (user['password_hash'] as String? ?? '')) {
        setState(() => _error = "Email ou mot de passe incorrect.");
        return;
      }

      final sp = await SharedPreferences.getInstance();
      await sp.setInt('current_user_id', (user['id'] as int));
      await sp.setString(
        'user_display_name',
        (user['display_name'] as String? ?? ''),
      );
      await sp.setString('user_email', (user['email'] as String? ?? ''));

      if (!mounted) return;
      Navigator.pop(context, true);
    } catch (_) {
      setState(() => _error = "Erreur de connexion.");
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _doSignup() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final name = _nameCtrl.text.trim();
      final email = _emailCtrl.text.trim().toLowerCase();
      final pass = _passCtrl.text;

      final salt = _randomSalt(16);
      final hash = sha256.convert(utf8.encode('$salt$pass')).toString();

      final id = await AppDb.instance.insertUser(
        email: email,
        passwordHash: hash,
        salt: salt,
        displayName: name,
      );

      final sp = await SharedPreferences.getInstance();
      await sp.setInt('current_user_id', id);
      await sp.setString('user_display_name', name);
      await sp.setString('user_email', email);

      if (!mounted) return;
      Navigator.pop(context, true);
    } catch (_) {
      setState(
        () => _error = "Impossible de créer le compte (email déjà utilisé ?)",
      );
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isLogin = _mode == _AuthMode.login;

    return Form(
      key: _formKey,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            isLogin ? 'Se connecter' : 'Créer un compte',
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 20),
          ),
          const SizedBox(height: 20),

          // Champs
          if (!isLogin) ...[
            TextFormField(
              controller: _nameCtrl,
              decoration: const InputDecoration(hintText: 'Nom complet'),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Requis' : null,
            ),
            const SizedBox(height: 10),
          ],
          TextFormField(
            controller: _emailCtrl,
            decoration: const InputDecoration(hintText: 'E-mail'),
            validator: (v) {
              if (v == null || v.isEmpty) return 'Requis';
              final emailRegex = RegExp(r'^[\w\.-]+@[\w\.-]+\.[a-zA-Z]{2,}$');
              if (!emailRegex.hasMatch(v.trim())) return 'Email invalide';
              return null;
            },
          ),
          const SizedBox(height: 10),
          TextFormField(
            controller: _passCtrl,
            obscureText: true,
            decoration: const InputDecoration(hintText: 'Mot de passe'),
            validator: (v) {
              if (v == null || v.isEmpty) return 'Requis';
              if (!isLogin && v.length < 6) return 'Min. 6 caractères';
              return null;
            },
          ),
          if (!isLogin) ...[
            const SizedBox(height: 10),
            TextFormField(
              controller: _confirmCtrl,
              obscureText: true,
              decoration: const InputDecoration(
                hintText: 'Confirmer le mot de passe',
              ),
              validator: (v) {
                if (!isLogin && v != _passCtrl.text) return 'Ne correspond pas';
                return null;
              },
            ),
          ],

          // Erreur
          if (_error != null) ...[
            const SizedBox(height: 10),
            Text(_error!, style: const TextStyle(color: Colors.red)),
          ],

          const SizedBox(height: 20),

          // Bouton principal
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _loading ? null : (isLogin ? _doLogin : _doSignup),
              style: ElevatedButton.styleFrom(
                backgroundColor: brandBlue,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                textStyle: const TextStyle(fontWeight: FontWeight.w700),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: Text(
                _loading ? 'Patiente...' : (isLogin ? 'Se connecter' : 'Créer'),
              ),
            ),
          ),

          const SizedBox(height: 18),

          // Ligne "Vous n’avez pas de compte ?"
          Wrap(
            alignment: WrapAlignment.center,
            spacing: 6,
            children: [
              Text(
                isLogin
                    ? 'Vous n’avez pas de compte ?'
                    : 'Vous avez déjà un compte ?',
                style: const TextStyle(color: Colors.black87),
              ),
              GestureDetector(
                onTap: _loading
                    ? null
                    : () => setState(() {
                        _mode = isLogin ? _AuthMode.signup : _AuthMode.login;
                        _error = null;
                      }),
                child: Text(
                  isLogin ? 'Inscrivez-vous' : 'Connectez-vous',
                  style: TextStyle(
                    color: brandYellow,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 12),

          // Bouton annuler
          TextButton(
            onPressed: _loading ? null : () => Navigator.pop(context, false),
            child: const Text('Annuler'),
          ),
        ],
      ),
    );
  }
}
