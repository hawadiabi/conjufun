// lib/config/levels_config.dart

import '../viewmodels/exercise_vm.dart' show GameLevel, Tense;

// Listes de verbes par niveau scolaire
import '../data/level_cycle1.dart' as cycle1;
import '../data/level_cycle2.dart' as cycle2;
import '../data/level_cycle3.dart' as cycle3;
import '../data/level_sec1.dart' as sec1;
import '../data/level_sec2.dart' as sec2;

/// Tous les temps que ton jeu sait gérer
const List<Tense> kAllSupportedTenses = [
  Tense.present,
  Tense.imparfait,
  Tense.futur,
  Tense.conditionnel,
  Tense.subjonctif,
  Tense.subjonctifImparfait,
  Tense.passeSimple,
  Tense.plusQueParfait,
  Tense.passeCompose,
  Tense.futurAnterieur,
  Tense.conditionnelPasse,
  Tense.futurProche,
  Tense.imperatif,
  Tense.subjonctifPasse,
  Tense.passeAnterieur,
  Tense.gerondif,
  Tense.participePresent,
  Tense.participePasse,
  Tense.infinitif,
  Tense.infinitifPasse,
];

/// Verbes autorisés par niveau
const Map<GameLevel, List<String>> kLevelVerbs = {
  GameLevel.level_cycle1: cycle1.kCycle1Verbs,

  GameLevel.level_cycle2: [...cycle1.kCycle1Verbs, ...cycle2.kCycle2Verbs],

  GameLevel.level_cycle3: [
    ...cycle1.kCycle1Verbs,
    ...cycle2.kCycle2Verbs,
    ...cycle3.kCycle3Verbs,
  ],

  GameLevel.level_sec1: [
    ...cycle1.kCycle1Verbs,
    ...cycle2.kCycle2Verbs,
    ...cycle3.kCycle3Verbs,
    ...sec1.kSec1Verbs,
  ],

  GameLevel.level_sec2: [
    ...cycle1.kCycle1Verbs,
    ...cycle2.kCycle2Verbs,
    ...cycle3.kCycle3Verbs,
    ...sec1.kSec1Verbs,
    ...sec2.kSec2Verbs,
  ],

  // Expert: géré à part avec LEFFF
  GameLevel.expert: [],
};

/// Temps autorisés par niveau
const Map<GameLevel, List<Tense>> kLevelTenses = {
  GameLevel.level_cycle1: [Tense.present, Tense.futurProche, Tense.imperatif],

  GameLevel.level_cycle2: [
    Tense.present,
    Tense.passeCompose,
    Tense.futurProche,
    Tense.imparfait,
    Tense.futur,
    Tense.imperatif,
  ],

  GameLevel.level_cycle3: [
    Tense.present,
    Tense.passeCompose,
    Tense.futurProche,
    Tense.imparfait,
    Tense.futur,
    Tense.imperatif,
  ],

  GameLevel.level_sec1: [
    Tense.present,
    Tense.passeCompose,
    Tense.futurProche,
    Tense.imparfait,
    Tense.futur,
    Tense.imperatif,
    Tense.conditionnel,
    Tense.passeSimple,
    Tense.subjonctif,
  ],

  GameLevel.level_sec2: [
    Tense.present,
    Tense.passeCompose,
    Tense.futurProche,
    Tense.imparfait,
    Tense.futur,
    Tense.imperatif,
    Tense.conditionnel,
    Tense.plusQueParfait,
    Tense.passeSimple,
    Tense.subjonctif,
    Tense.conditionnelPasse,
    Tense.futurAnterieur,
  ],
  GameLevel.expert: [],
};
