import 'dart:convert';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:shared_preferences/shared_preferences.dart';
import '../models/custom_set.dart';
import '../data/app_db.dart';
import '../config/levels_config.dart'
    show kLevelVerbs, kLevelTenses, kAllSupportedTenses;

// ------------------------------------------------------
// 1) Enum des temps + classe Exercise
// ------------------------------------------------------

enum Tense {
  present,
  imparfait,
  futur,
  conditionnel,
  subjonctif,
  subjonctifImparfait,
  passeSimple,
  plusQueParfait,
  passeCompose,
  futurAnterieur,
  conditionnelPasse,
  futurProche,
  imperatif,
  subjonctifPasse,
  passeAnterieur,
  gerondif,
  participePresent,
  infinitif,
  participePasse,
  infinitifPasse,
}

extension TenseLabel on Tense {
  String get label {
    switch (this) {
      case Tense.present:
        return 'présent';
      case Tense.imparfait:
        return 'imparfait';
      case Tense.futur:
        return 'futur simple';
      case Tense.conditionnel:
        return 'conditionnel présent';
      case Tense.subjonctif:
        return 'subjonctif présent';
      case Tense.subjonctifImparfait:
        return 'subjonctif imparfait';
      case Tense.passeSimple:
        return 'passé simple';
      case Tense.plusQueParfait:
        return 'plus-que-parfait';
      case Tense.passeCompose:
        return 'passé composé';
      case Tense.futurAnterieur:
        return 'futur antérieur';
      case Tense.conditionnelPasse:
        return 'conditionnel passé';
      case Tense.futurProche:
        return 'futur proche';
      case Tense.imperatif:
        return 'impératif';
      case Tense.subjonctifPasse:
        return 'subjonctif passé';
      case Tense.passeAnterieur:
        return 'passé antérieur';
      case Tense.gerondif:
        return 'gérondif';
      case Tense.participePresent:
        return 'participe présent';
      case Tense.infinitif:
        return 'infinitif';
      case Tense.participePasse:
        return 'participe passé';
      case Tense.infinitifPasse:
        return 'infinitif passé';
    }
  }
}

class Exercise {
  final String infinitif;
  final String pronom;
  final String reponseAttendue;
  final Tense tense;

  Exercise({
    required this.infinitif,
    required this.pronom,
    required this.reponseAttendue,
    required this.tense,
  });

  String get verb => infinitif;
  String get pronoun => pronom;
  String get correctAnswer => reponseAttendue;
  String get tenseLabel => tense.label;
}

// ------------------------------------------------------
// 2) Badges globaux
// ------------------------------------------------------

enum BadgeRank { none, bronze, silver, gold, diamond }

class BadgeInfo {
  final BadgeRank rank;
  final int nextThreshold;

  const BadgeInfo(this.rank, this.nextThreshold);
}

const Map<BadgeRank, int> _badgeThresholds = {
  BadgeRank.bronze: 1000,
  BadgeRank.silver: 5000,
  BadgeRank.gold: 15000,
  BadgeRank.diamond: 40000,
};

BadgeInfo computeBadgeFromTotal(int total) {
  if (total >= _badgeThresholds[BadgeRank.diamond]!) {
    return const BadgeInfo(BadgeRank.diamond, 0);
  } else if (total >= _badgeThresholds[BadgeRank.gold]!) {
    return BadgeInfo(
      BadgeRank.gold,
      _badgeThresholds[BadgeRank.diamond]! - total,
    );
  } else if (total >= _badgeThresholds[BadgeRank.silver]!) {
    return BadgeInfo(
      BadgeRank.silver,
      _badgeThresholds[BadgeRank.gold]! - total,
    );
  } else if (total >= _badgeThresholds[BadgeRank.bronze]!) {
    return BadgeInfo(
      BadgeRank.bronze,
      _badgeThresholds[BadgeRank.silver]! - total,
    );
  } else {
    return BadgeInfo(
      BadgeRank.none,
      _badgeThresholds[BadgeRank.bronze]! - total,
    );
  }
}

String badgeLabel(BadgeRank rank) {
  switch (rank) {
    case BadgeRank.none:
      return 'Aucun badge';
    case BadgeRank.bronze:
      return '🥉 Badge Bronze';
    case BadgeRank.silver:
      return '🥈 Badge Argent';
    case BadgeRank.gold:
      return '🥇 Badge Or';
    case BadgeRank.diamond:
      return '💎 Badge Diamant';
  }
}

// ------------------------------------------------------
// 3) Modes / niveaux
// ------------------------------------------------------

enum VmSessionMode { unlimited, fixed }

enum GameLevel {
  level_cycle1,
  level_cycle2,
  level_cycle3,
  level_sec1,
  level_sec2,
  expert,
}

const List<GameLevel> kPlacementOrder = [
  GameLevel.level_cycle1,
  GameLevel.level_cycle2,
  GameLevel.level_cycle3,
  GameLevel.level_sec1,
  GameLevel.level_sec2,
  GameLevel.expert,
];

class LevelPlacementConfig {
  final GameLevel level;
  final double minSuccessRate;

  const LevelPlacementConfig({
    required this.level,
    required this.minSuccessRate,
  });
}

class LevelTestQuestionSpec {
  final GameLevel level;
  final Tense tense;

  const LevelTestQuestionSpec({required this.level, required this.tense});
}

class LevelPlacementResult {
  final GameLevel recommendedLevel;
  final Map<GameLevel, LevelScore> levelScores;

  const LevelPlacementResult({
    required this.recommendedLevel,
    required this.levelScores,
  });
}

class LevelScore {
  final int correct;
  final int total;

  const LevelScore({required this.correct, required this.total});

  double get successRate => total == 0 ? 0.0 : correct / total;
}

const List<LevelPlacementConfig> kPlacementConfigs = [
  LevelPlacementConfig(level: GameLevel.level_cycle1, minSuccessRate: 0.6),
  LevelPlacementConfig(level: GameLevel.level_cycle2, minSuccessRate: 0.6),
  LevelPlacementConfig(level: GameLevel.level_cycle3, minSuccessRate: 0.6),
  LevelPlacementConfig(level: GameLevel.level_sec1, minSuccessRate: 0.65),
  LevelPlacementConfig(level: GameLevel.level_sec2, minSuccessRate: 0.65),
  LevelPlacementConfig(level: GameLevel.expert, minSuccessRate: 0.7),
];

// ------------------------------------------------------
// 4) ViewModel
// ------------------------------------------------------

class ExerciseViewModel extends ChangeNotifier {
  Exercise? _currentExercise;
  int _score = 0;
  int _highScore = 0;
  VmSessionMode _mode = VmSessionMode.unlimited;
  GameLevel _level = GameLevel.level_cycle1;
  CustomSet? _customSet;

  int? _userId;
  void setCurrentUserId(int? id) => _userId = id;
  int? get userId => _userId;

  int correctCount = 0;

  DateTime _sessionStart = DateTime.now();
  int _askedCount = 0;
  int _targetCount = 0;

  int currentStreak = 0;
  int bestStreak = 0;

  int questionStreak = 0;
  int bestQuestionStreak = 0;

  // données lefff
  Map<String, dynamic> _lefff = {};

  // modèle règles grammaire
  Map<String, dynamic>? _grammarModel;

  final _rng = Random();

  final List<String> _persons = const ['je', 'tu', 'il', 'nous', 'vous', 'ils'];

  String _randomPronounForIndex(int index, String verbForm) {
    final i = index.clamp(0, _persons.length - 1);
    switch (i) {
      case 0:
        return _contractPronoun('je', verbForm);
      case 1:
        return 'tu';
      case 2:
        return _rng.nextBool() ? 'il' : 'elle';
      case 3:
        return 'nous';
      case 4:
        return 'vous';
      case 5:
        return _rng.nextBool() ? 'ils' : 'elles';
      default:
        return _contractPronoun('je', verbForm);
    }
  }

  final Map<String, String> _tenseNames = const {
    'P': 'présent',
    'I': 'imparfait',
    'F': 'futur simple',
    'C': 'conditionnel présent',
    'S': 'subjonctif présent',
    'T': 'subjonctif imparfait',
    'J': 'passé simple',
    'Y': 'impératif',
    'PC': 'passé composé',
    'FP': 'futur proche',
  };

  static const Set<String> _etreVerbs = {
    'aller',
    'venir',
    'arriver',
    'partir',
    'entrer',
    'rentrer',
    'sortir',
    'retourner',
    'monter',
    'descendre',
    'tomber',
    'rester',
    'passer',
    'naître',
    'mourir',
    'devenir',
    'revenir',
    'parvenir',
    'survenir',
    'intervenir',
    'advenir',
  };

  Exercise? get currentExercise => _currentExercise;
  int get score => _score;
  int get highScore => _highScore;
  VmSessionMode get mode => _mode;
  GameLevel get level => _level;
  int get askedCount => _askedCount;
  int get targetCount => _targetCount;

  void resetScore() {
    _score = 0;
    notifyListeners();
  }

  String get levelString {
    switch (_level) {
      case GameLevel.level_cycle1:
        return 'level_cycle1';
      case GameLevel.level_cycle2:
        return 'level_cycle2';
      case GameLevel.level_cycle3:
        return 'level_cycle3';
      case GameLevel.level_sec1:
        return 'level_sec1';
      case GameLevel.level_sec2:
        return 'level_sec2';
      case GameLevel.expert:
        return 'expert';
    }
  }

  int get successPercent {
    final denom = (_mode == VmSessionMode.fixed)
        ? _targetCount
        : (_askedCount == 0 ? 1 : _askedCount);

    final ratio = denom == 0 ? 0.0 : (correctCount / denom);
    return (ratio * 100).round();
  }

  String get progressLabel {
    if (_mode != VmSessionMode.fixed || _targetCount <= 0) return '';
    return '$_askedCount/$_targetCount';
  }

  // ------------------------------------------------------
  // 5) Mapping temps
  // ------------------------------------------------------

  String _tenseToSimpleCode(Tense t) {
    switch (t) {
      case Tense.present:
        return 'P';
      case Tense.imparfait:
        return 'I';
      case Tense.futur:
        return 'F';
      case Tense.conditionnel:
        return 'C';
      case Tense.subjonctif:
        return 'S';
      case Tense.subjonctifImparfait:
        return 'T';
      case Tense.passeSimple:
        return 'J';
      case Tense.participePasse:
        return 'K';
      default:
        return 'P';
    }
  }

  String? _tenseToCompoundCode(Tense t) {
    switch (t) {
      case Tense.passeCompose:
        return 'PC';
      case Tense.plusQueParfait:
        return 'PQP';
      case Tense.futurAnterieur:
        return 'FA';
      case Tense.conditionnelPasse:
        return 'CP';
      case Tense.subjonctifPasse:
        return 'SP';
      case Tense.passeAnterieur:
        return 'PA';
      case Tense.futurProche:
        return 'FP';
      default:
        return null;
    }
  }

  Tense _mapLabelToTense(String label) {
    switch (label) {
      case 'présent':
        return Tense.present;
      case 'imparfait':
        return Tense.imparfait;
      case 'futur simple':
        return Tense.futur;
      case 'conditionnel présent':
        return Tense.conditionnel;
      case 'subjonctif présent':
        return Tense.subjonctif;
      case 'subjonctif imparfait':
        return Tense.subjonctifImparfait;
      case 'passé simple':
        return Tense.passeSimple;
      case 'plus-que-parfait':
        return Tense.plusQueParfait;
      case 'passé composé':
        return Tense.passeCompose;
      case 'futur antérieur':
        return Tense.futurAnterieur;
      case 'conditionnel passé':
        return Tense.conditionnelPasse;
      case 'futur proche':
        return Tense.futurProche;
      default:
        return Tense.present;
    }
  }

  // ------------------------------------------------------
  // 6) Chargement données
  // ------------------------------------------------------

  Future<void> _loadLefff() async {
    if (_lefff.isNotEmpty) return;
    try {
      final raw = await rootBundle.loadString(
        'assets/data/lefff_conjugations.json',
      );
      _lefff = json.decode(raw) as Map<String, dynamic>;
    } catch (e) {
      debugPrint('Erreur chargement lefff_conjugations.json : $e');
      _lefff = {};
    }
  }

  Future<void> _loadGrammarModel() async {
    try {
      final jsonStr = await rootBundle.loadString(
        'assets/data/grammar_rules.json',
      );
      _grammarModel = json.decode(jsonStr) as Map<String, dynamic>;
    } catch (e) {
      debugPrint('Erreur grammar_rules.json : $e');
      _grammarModel = {};
    }
  }

  Future<void> _loadRecord() async {
    final modeStr = (_mode == VmSessionMode.unlimited) ? 'unlimited' : 'fixed';
    _highScore = await AppDb.instance.getRecordByLevelAndMode(
      level: levelString,
      mode: modeStr,
      userId: _userId,
    );
  }

  /// init pour le jeu
  Future<void> init() async {
    await AppDb.instance.database;
    await _loadLefff();
    await _loadGrammarModel();
    await _loadRecord();
    await refreshStreaks();
    await nextExercise();
  }

  Future<void> initForVerbList() async {
    await _loadLefff();
    await _loadGrammarModel();
  }

  // ------------------------------------------------------
  // 7) Config session
  // ------------------------------------------------------

  Future<void> configureSession({
    required VmSessionMode mode,
    required int fixedCount,
    required GameLevel level,
    CustomSet? customSet,
  }) async {
    _mode = mode;
    _targetCount = (mode == VmSessionMode.fixed) ? fixedCount : 0;
    _level = level;
    _customSet = customSet;
    _score = 0;
    correctCount = 0;
    _askedCount = 0;
    _sessionStart = DateTime.now();
    questionStreak = 0;
    bestQuestionStreak = 0;

    await _loadRecord();
    notifyListeners();
  }

  void incrementAskedIfFixed() {
    if (_mode == VmSessionMode.fixed) {
      notifyListeners();
    }
  }

  Future<LevelPlacementResult> runPlacementTest({
    required Future<bool> Function(Exercise exercise) askQuestionAndGetResult,
  }) async {
    final Map<GameLevel, LevelScore> scores = {};
    GameLevel? recommended;

    for (final config in kPlacementConfigs) {
      final score = await _runPlacementLevel(
        level: config.level,
        askQuestionAndGetResult: askQuestionAndGetResult,
      );

      scores[config.level] = score;

      if (score.successRate < config.minSuccessRate) {
        recommended = config.level;
        break;
      }
    }

    recommended ??= kPlacementConfigs.last.level;

    return LevelPlacementResult(
      recommendedLevel: recommended,
      levelScores: scores,
    );
  }

  Future<LevelScore> _runPlacementLevel({
    required GameLevel level,
    required Future<bool> Function(Exercise exercise) askQuestionAndGetResult,
  }) async {
    final specs = _buildPlacementSpecsForLevel(level);

    int correct = 0;
    int total = 0;

    for (final spec in specs) {
      final ex = await generateExerciseForLevelAndTense(level, spec.tense);
      if (ex == null) continue;

      final isCorrect = await askQuestionAndGetResult(ex);
      total++;
      if (isCorrect) correct++;
    }

    return LevelScore(correct: correct, total: total);
  }

  List<LevelTestQuestionSpec> _buildPlacementSpecsForLevel(GameLevel level) {
    final List<Tense> tenses = level == GameLevel.expert
        ? List<Tense>.from(kAllSupportedTenses)
        : List<Tense>.from(kLevelTenses[level] ?? const []);

    final List<LevelTestQuestionSpec> specs = [];

    final Set<Tense> importantTenses = {
      Tense.present,
      Tense.passeCompose,
      Tense.imparfait,
      Tense.futur,
      Tense.futurProche,
      Tense.conditionnel,
    };

    for (final tense in tenses) {
      final bool isImportant = importantTenses.contains(tense);

      final int questionCount = isImportant
          ? (level == GameLevel.level_sec1 ||
                    level == GameLevel.level_sec2 ||
                    level == GameLevel.expert
                ? 3
                : 2)
          : 1;

      for (int i = 0; i < questionCount; i++) {
        specs.add(LevelTestQuestionSpec(level: level, tense: tense));
      }
    }

    specs.shuffle(_rng);
    return specs;
  }

  // ------------------------------------------------------
  // 8) Génération exercices
  // ------------------------------------------------------

  Future<void> nextExercise() async {
    await _loadLefff();

    Exercise? ex;

    // 1) Si mode créateur actif -> on génère depuis le set
    if (_customSet != null) {
      final raw = await AppDb.instance.getRandomExerciseForCustomSet(
        _customSet!,
      );
      if (raw != null) {
        final tenseLabel = raw['tense'] as String;
        ex = Exercise(
          infinitif: raw['verb'] as String,
          pronom: raw['pronoun'] as String,
          reponseAttendue: raw['correct_answer'] as String,
          tense: _mapLabelToTense(tenseLabel),
        );
      }
    } else {
      // 2) Sinon normal: lefff / niveaux
      ex = _randomFromLefff();
      if (ex == null) {
        final raw = await AppDb.instance.getRandomExerciseRaw();
        if (raw != null) {
          final tenseLabel = raw['tense'] as String;
          ex = Exercise(
            infinitif: raw['verb'] as String,
            pronom: raw['pronoun'] as String,
            reponseAttendue: raw['correct_answer'] as String,
            tense: _mapLabelToTense(tenseLabel),
          );
        }
      }
    }

    if (ex != null) {
      _currentExercise = ex;
      notifyListeners();
    }
  }

  bool _isNoPronounTense(Tense t) {
    return t == Tense.infinitif ||
        t == Tense.infinitifPasse ||
        t == Tense.participePresent ||
        t == Tense.participePasse ||
        t == Tense.gerondif;
  }

  Exercise? _randomFromLefff() {
    if (_lefff.isEmpty) return null;

    List<String> verbs;
    List<Tense> tenses;

    if (_level == GameLevel.expert) {
      verbs = _lefff.keys.toList();
      tenses = kAllSupportedTenses;
    } else {
      final configVerbs = kLevelVerbs[_level] ?? const [];
      final configTenses = kLevelTenses[_level] ?? const [];

      if (configVerbs.isEmpty || configTenses.isEmpty) {
        verbs = _lefff.keys.toList();
        tenses = kAllSupportedTenses;
      } else {
        verbs = configVerbs.where((v) => _lefff.containsKey(v)).toList();
        tenses = configTenses;
      }
    }

    if (verbs.isEmpty || tenses.isEmpty) return null;

    final verb = verbs[_rng.nextInt(verbs.length)];
    final rawEntry = _lefff[verb];
    if (rawEntry is! Map) return null;
    final Map<String, dynamic> verbTenses = rawEntry.cast<String, dynamic>();

    final tense = tenses[_rng.nextInt(tenses.length)];

    final forms = _buildFormsFor(
      verb: verb,
      tense: tense,
      verbTenses: verbTenses,
    );
    if (forms.isEmpty) return null;

    int idx = 0;
    String form = '';
    int safety = 0;
    final maxIdx = forms.length.clamp(1, 6);
    do {
      idx = _rng.nextInt(maxIdx);
      form = forms[idx].toString().trim();
      safety++;
    } while ((form.isEmpty || form == 'NA') && safety < 10);

    if (form.isEmpty || form == 'NA') {
      form = forms.first.toString().trim();
      idx = 0;
    }

    String pronoun;
    if (_isNoPronounTense(tense)) {
      pronoun = '(aucun pronom)';
    } else {
      pronoun = _randomPronounForIndex(idx, form);
    }

    return Exercise(
      infinitif: verb,
      pronom: pronoun,
      reponseAttendue: form,
      tense: tense,
    );
  }

  Future<Exercise?> generateExerciseForLevelAndTense(
    GameLevel level,
    Tense tense,
  ) async {
    await _loadLefff();
    if (_lefff.isEmpty) return null;

    List<String> verbs;
    List<Tense> tenses;

    if (level == GameLevel.expert) {
      verbs = _lefff.keys.toList();
      tenses = kAllSupportedTenses;
    } else {
      final configVerbs = kLevelVerbs[level] ?? const [];
      final configTenses = kLevelTenses[level] ?? const [];

      if (configVerbs.isEmpty || configTenses.isEmpty) {
        verbs = _lefff.keys.toList();
        tenses = kAllSupportedTenses;
      } else {
        verbs = configVerbs.where((v) => _lefff.containsKey(v)).toList();
        tenses = configTenses;
      }
    }

    if (verbs.isEmpty) return null;

    final verb = verbs[_rng.nextInt(verbs.length)];
    final rawEntry = _lefff[verb];
    if (rawEntry is! Map) return null;
    final Map<String, dynamic> verbTenses = rawEntry.cast<String, dynamic>();

    final forms = _buildFormsFor(
      verb: verb,
      tense: tense,
      verbTenses: verbTenses,
    );
    if (forms.isEmpty) return null;

    int idx = 0;
    String form = '';
    int safety = 0;
    final maxIdx = forms.length.clamp(1, 6);
    do {
      idx = _rng.nextInt(maxIdx);
      form = forms[idx].toString().trim();
      safety++;
    } while ((form.isEmpty || form == 'NA') && safety < 10);

    if (form.isEmpty || form == 'NA') {
      form = forms.first.toString().trim();
      idx = 0;
    }

    String pronoun;
    if (_isNoPronounTense(tense)) {
      pronoun = '(aucun pronom)';
    } else {
      pronoun = _randomPronounForIndex(idx, form);
    }

    return Exercise(
      infinitif: verb,
      pronom: pronoun,
      reponseAttendue: form,
      tense: tense,
    );
  }

  List<String> _buildFormsFor({
    required String verb,
    required Tense tense,
    required Map<String, dynamic> verbTenses,
  }) {
    List<String> forms = [];

    if (tense == Tense.futurProche) {
      forms = _buildFuturProcheForms(verb: verb, allVerbs: _lefff);
      return forms;
    }

    if (tense == Tense.infinitif) {
      final rawW = verbTenses['W'];
      if (rawW is! List || rawW.isEmpty) return [];
      final inf = rawW.first.toString().trim();
      if (inf.isEmpty) return [];
      return List<String>.filled(6, inf);
    }

    if (tense == Tense.infinitifPasse) {
      return _buildInfinitifPasseForms(verb: verb, verbTenses: verbTenses);
    }

    if (tense == Tense.participePresent) {
      final rawG = verbTenses['G'];
      if (rawG is! List || rawG.isEmpty) return [];
      final gForm = rawG.first.toString().trim();
      if (gForm.isEmpty) return [];
      return List<String>.filled(6, gForm);
    }

    if (tense == Tense.gerondif) {
      final rawG = verbTenses['G'];
      if (rawG is! List || rawG.isEmpty) return [];
      final gForm = rawG.first.toString().trim();
      if (gForm.isEmpty) return [];
      final ger = 'en $gForm';
      return List<String>.filled(6, ger);
    }

    if (tense == Tense.imperatif) {
      final rawY = verbTenses['Y'];
      if (rawY is! List) return [];
      final yForms = List<String>.from(rawY);
      if (yForms.length < 6) return [];
      return yForms;
    }

    final compoundCode = _tenseToCompoundCode(tense);
    if (compoundCode != null) {
      // BUG CORRIGÉ : l'ancien code retombait silencieusement sur les
      // formes du présent simple quand _buildCompoundForms échouait
      // (participe passé manquant dans le LEFFF, auxiliaire introuvable,
      // données incomplètes, etc.). Concrètement, un élève qui demandait
      // le passé composé d'un verbe aux données partielles pouvait se
      // voir présenter — et corriger — une forme au présent sans le
      // savoir, ce qui fausse silencieusement l'évaluation pédagogique.
      //
      // _buildFormsFor (cette fonction) est déjà appelée par du code qui
      // gère correctement une liste vide en retournant null et en
      // retentant avec un autre verbe/temps (voir l'appelant : "if
      // (forms.isEmpty) return null;"). On laisse donc cet échec se
      // propager normalement plutôt que de masquer la donnée incorrecte.
      return _buildCompoundForms(
        verb: verb,
        verbTenses: verbTenses,
        allVerbs: _lefff,
        compoundCode: compoundCode,
      );
    }

    final baseCode = _tenseToSimpleCode(tense);
    final rawForms = verbTenses[baseCode];
    if (rawForms is! List) return [];
    return List<String>.from(rawForms);
  }

  List<String> _buildCompoundForms({
    required String verb,
    required Map<String, dynamic> verbTenses,
    required Map<String, dynamic> allVerbs,
    required String compoundCode,
  }) {
    final ppRaw = verbTenses['K'];
    if (ppRaw is! List) return [];
    final ppList = List<String>.from(ppRaw);
    if (ppList.isEmpty) return [];
    final pp = ppList.first.trim();
    if (pp.isEmpty) return [];

    final auxVerb = _etreVerbs.contains(verb) ? 'être' : 'avoir';
    final auxRaw = allVerbs[auxVerb];
    if (auxRaw is! Map) return [];
    final auxTenses = auxRaw.cast<String, dynamic>();

    String baseCode;
    switch (compoundCode) {
      case 'PC':
        baseCode = 'P';
        break;
      case 'PQP':
        baseCode = 'I';
        break;
      case 'FA':
        baseCode = 'F';
        break;
      case 'CP':
        baseCode = 'C';
        break;
      case 'SP':
        baseCode = 'S';
        break;
      case 'PA':
        baseCode = 'J';
        break;
      default:
        return [];
    }

    final auxFormsRaw = auxTenses[baseCode];
    if (auxFormsRaw is! List) return [];
    final auxForms = List<String>.from(auxFormsRaw);
    if (auxForms.length < 6) return [];

    return List<String>.generate(6, (i) {
      final aux = auxForms[i].toString().trim();
      if (aux.isEmpty) return pp;
      return '$aux $pp';
    });
  }

  List<String> _buildFuturProcheForms({
    required String verb,
    required Map<String, dynamic> allVerbs,
  }) {
    final rawAller = allVerbs['aller'];
    if (rawAller is! Map) return [];
    final allerTenses = rawAller.cast<String, dynamic>();

    final presentRaw = allerTenses['P'];
    if (presentRaw is! List) return [];
    final presentForms = List<String>.from(presentRaw);
    if (presentForms.length < 6) return [];

    return List<String>.generate(6, (i) {
      final aux = presentForms[i].toString().trim();
      if (aux.isEmpty) return verb;
      return '$aux $verb';
    });
  }

  List<String> _buildInfinitifPasseForms({
    required String verb,
    required Map<String, dynamic> verbTenses,
  }) {
    final ppRaw = verbTenses['K'];
    if (ppRaw is! List) return [];
    final ppList = List<String>.from(ppRaw);
    if (ppList.isEmpty) return [];
    final pp = ppList.first.trim();
    if (pp.isEmpty) return [];

    final auxVerb = _etreVerbs.contains(verb) ? 'être' : 'avoir';
    final form = '$auxVerb $pp';
    return List<String>.filled(6, form);
  }

  // ------------------------------------------------------
  // 10) Conjugaison complète (explications)
  // ------------------------------------------------------

  Map<String, String> getFullConjugationForCurrent() {
    if (_currentExercise == null) return {};
    return getFullConjugationForExercise(_currentExercise!);
  }

  Map<String, String> getFullConjugationForExercise(Exercise ex) {
    if (_lefff.isEmpty) return {ex.pronoun: ex.correctAnswer};

    final rawEntry = _lefff[ex.verb];
    if (rawEntry is! Map) {
      return {ex.pronoun: ex.correctAnswer};
    }
    final verbTenses = rawEntry.cast<String, dynamic>();

    final forms = _buildFormsFor(
      verb: ex.verb,
      tense: ex.tense,
      verbTenses: verbTenses,
    );
    if (forms.isEmpty) {
      return {ex.pronoun: ex.correctAnswer};
    }

    final result = <String, String>{};
    final max = forms.length.clamp(0, _persons.length);
    for (int i = 0; i < max; i++) {
      final form = forms[i].trim();
      if (form.isEmpty || form == 'NA') continue;

      final basePronoun = _persons[i];
      final displayPronoun = _contractPronoun(basePronoun, form);

      result[displayPronoun] = form;
    }

    if (result.isEmpty) {
      return {ex.pronoun: ex.correctAnswer};
    }
    return result;
  }

  // ------------------------------------------------------
  // 11) Explications grammaticales
  // ------------------------------------------------------

  String _findVerbGroupKey(String verb) {
    if (_grammarModel == null || !_grammarModel!.containsKey('verb_families')) {
      if (verb.endsWith('er')) return 'er';
      if (verb.endsWith('ir')) return 'ir_finir';
      return 'er';
    }

    final families = _grammarModel!['verb_families'] as Map<String, dynamic>;

    for (final entry in families.entries) {
      final key = entry.key;
      final list = (entry.value as List).cast<String>();
      if (list.contains(verb)) {
        return key;
      }
    }

    if (verb.endsWith('er')) return 'er';
    if (verb.endsWith('ir')) return 'ir_finir';
    return 'er';
  }

  String _contractPronoun(String pronoun, String verbForm) {
    if (pronoun.toLowerCase() != 'je') return pronoun;

    final trimmed = verbForm.trim().toLowerCase();
    if (trimmed.isEmpty) return 'je';

    const vowels = ['a', 'e', 'i', 'o', 'u', 'y'];

    final first = trimmed[0];

    if (vowels.contains(first) || first == 'h') {
      return "j'";
    }

    return 'je';
  }

  String _computeRadical(String verb, String groupKey) {
    if (groupKey == 'er') {
      if (verb.endsWith('er')) {
        return verb.substring(0, verb.length - 2);
      }
    } else if (groupKey == 'ir_finir') {
      if (verb.endsWith('ir')) {
        return verb.substring(0, verb.length - 2);
      }
    }
    if (verb.length > 2) {
      return verb.substring(0, verb.length - 2);
    }
    return verb;
  }

  String _buildExampleConjugation(
    String verb,
    Map<String, String> endings,
    String pattern,
    String groupKey,
  ) {
    String base;

    String formFor(String label, String pronoun) {
      switch (pattern) {
        case 'infinitive_plus_ending':
          base = verb;
          break;
        case 'radical_plus_ending':
        default:
          base = _computeRadical(verb, groupKey);
          break;
      }
      final ending = endings[label] ?? '';
      final verbForm = base + ending;
      final contractedPronoun = _contractPronoun(pronoun, verbForm);
      return '$contractedPronoun $verbForm';
    }

    final forms = <String>[
      formFor('je', 'je'),
      formFor('tu', 'tu'),
      formFor('il/elle', 'il/elle'),
      formFor('nous', 'nous'),
      formFor('vous', 'vous'),
      formFor('ils/elles', 'ils/elles'),
    ];

    return 'Exemple avec « $verb » : ${forms.join(', ')}.';
  }

  String getExplanationForCurrent() {
    if (_grammarModel == null ||
        _grammarModel!.isEmpty ||
        _currentExercise == null) {
      return '';
    }

    final ex = _currentExercise!;
    final verb = ex.verb.toLowerCase();
    final pronoun = ex.pronoun.toLowerCase();
    final tenseLabel = ex.tenseLabel.toLowerCase();
    final correct = ex.correctAnswer;

    final b = StringBuffer();

    final contracted = _contractPronoun(pronoun, correct);
    b.writeln('Rappel : $contracted $verb au $tenseLabel → $correct.');

    String tenseKey = 'present';
    if (tenseLabel.contains('imparfait')) {
      tenseKey = 'imparfait';
    } else if (tenseLabel.contains('futur')) {
      tenseKey = 'futur';
    } else if (tenseLabel.contains('passé composé')) {
      tenseKey = 'passe_compose';
    } else if (tenseLabel.contains('conditionnel')) {
      tenseKey = 'conditional';
    } else if (tenseLabel.contains('présent')) {
      tenseKey = 'present';
    }

    if (tenseKey == 'passe_compose') {
      try {
        final tenses = _grammarModel!['tenses'] as Map<String, dynamic>;
        final label =
            (tenses['passe_compose'] as Map<String, dynamic>)['label'];
        final generic = _grammarModel!['passe_compose_generic'] as String;
        b.writeln();
        b.writeln('Au $label :');
        b.writeln(generic);
      } catch (_) {}
      return b.toString();
    }

    final String groupKey = _findVerbGroupKey(verb);

    final groups = _grammarModel!['groups'] as Map<String, dynamic>;
    final group = groups[groupKey] as Map<String, dynamic>;
    final groupName = group['name'] as String;
    final exampleVerb = group['example'] as String;

    if (!group.containsKey(tenseKey)) {
      b.writeln();
      b.writeln(
        'Ce temps n\'est pas encore détaillé pour le groupe « $groupName ».',
      );
      return b.toString();
    }

    final tenseData = group[tenseKey] as Map<String, dynamic>;
    final pattern = (tenseData['pattern'] as String?) ?? 'radical_plus_ending';

    final tenses = _grammarModel!['tenses'] as Map<String, dynamic>;
    final tenseMeta = tenses[tenseKey] as Map<String, dynamic>;
    final tenseNiceLabel = tenseMeta['label'] as String;

    b.writeln();
    b.writeln('Groupe : $groupName.');
    b.writeln('Temps : $tenseNiceLabel.');

    if (pattern == 'custom_example') {
      final line = tenseData['example_line'] as String;
      b.writeln(line);
    } else {
      final endingsRaw = tenseData['endings'] as Map<String, dynamic>;
      final endings = endingsRaw.map((k, v) => MapEntry(k, v as String));
      final exampleLine = _buildExampleConjugation(
        exampleVerb,
        endings,
        pattern,
        groupKey,
      );
      b.writeln(exampleLine);
    }

    return b.toString();
  }

  // ------------------------------------------------------
  // 12) Vérification / score / badges
  // ------------------------------------------------------

  bool isAnswerCorrect(String userAnswer) {
    final correct = _currentExercise?.correctAnswer.trim().toLowerCase();
    return userAnswer.trim().toLowerCase() == correct;
  }

  int pointsForCurrent() {
    switch (_level) {
      case GameLevel.level_cycle1:
        return 5;
      case GameLevel.level_cycle2:
        return 8;
      case GameLevel.level_cycle3:
        return 11;
      case GameLevel.level_sec1:
        return 14;
      case GameLevel.level_sec2:
        return 17;
      case GameLevel.expert:
        return 20;
    }
  }

  void addPointsForCurrent() {
    final pts = pointsForCurrent();
    _score += pts;
    correctCount++;
    _askedCount++;

    questionStreak++;
    if (questionStreak > bestQuestionStreak)
      bestQuestionStreak = questionStreak;

    notifyListeners();
  }

  void resetQuestionStreak() {
    questionStreak = 0;
    notifyListeners();
  }

  Future<void> _logCurrentRun() async {
    final totalTarget = (_mode == VmSessionMode.fixed)
        ? _targetCount
        : _askedCount;

    await AppDb.instance.insertRun(
      startedAt: _sessionStart,
      mode: (_mode == VmSessionMode.unlimited) ? 'unlimited' : 'fixed',
      level: levelString,
      totalTarget: totalTarget < 0 ? 0 : totalTarget,
      correctCount: correctCount < 0 ? 0 : correctCount,
      score: _score < 0 ? 0 : _score,
      userId: _userId,
    );

    if (_userId != null) {
      final streaks = await AppDb.instance.updateStreakAfterSession(
        userId: _userId!,
        sessionTime: DateTime.now(),
      );
      currentStreak = streaks['current'] ?? 0;
      bestStreak = streaks['best'] ?? 0;
    }

    notifyListeners();
  }

  Future<bool> onWrongAnswerAndMaybeUpdateRecord() async {
    questionStreak = 0;
    _askedCount++;

    final prevBest = await AppDb.instance.getRecordByLevelAndMode(
      level: levelString,
      mode: 'unlimited',
      userId: _userId,
    );
    await _logCurrentRun();
    final isNew = _score > prevBest;
    _highScore = isNew ? _score : prevBest;
    return isNew;
  }

  Future<bool> finalizeAndMaybeRecord() async {
    final prevBest = await AppDb.instance.getRecordByLevelAndMode(
      level: levelString,
      mode: 'fixed',
      userId: _userId,
    );
    await _logCurrentRun();
    final isNew = _score > prevBest;
    _highScore = isNew ? _score : prevBest;
    return isNew;
  }

  Future<BadgeInfo?> computeGlobalBadge() async {
    if (_userId == null) return null;

    final total = await AppDb.instance.getTotalScoreForUser(_userId);
    return computeBadgeFromTotal(total);
  }

  /// Tente de débloquer un badge pour un utilisateur donné si la condition
  /// est remplie et que le badge n'est pas déjà débloqué.
  ///
  /// Extrait en méthode de classe (auparavant une fonction locale capturée
  /// par closure à l'intérieur de checkForNewBadges) pour deux raisons :
  /// - testabilité : on peut maintenant écrire un test unitaire qui appelle
  ///   directement _tryUnlockBadge sans devoir invoquer tout
  ///   checkForNewBadges avec son lot de requêtes DB ;
  /// - lisibilité : visible dans l'aperçu des méthodes de la classe au lieu
  ///   d'être enterrée au milieu d'une autre fonction.
  ///
  /// Retourne le message UI si le badge vient d'être débloqué, ou null
  /// sinon (condition non remplie, ou badge déjà possédé).
  Future<String?> _tryUnlockBadge({
    required int userId,
    required String code,
    required String title,
    String? description,
    required bool condition,
    required String uiMessage,
  }) async {
    if (!condition) return null;
    final hasIt = await AppDb.instance.userHasBadge(userId, code);
    if (hasIt) return null;

    await AppDb.instance.insertBadge(
      userId: userId,
      code: code,
      title: title,
      description: description,
    );

    return uiMessage;
  }

  Future<List<String>> checkForNewBadges() async {
    if (_userId == null) return [];

    final userId = _userId!;

    // ---------------------------------------
    // 1) Récupération des stats globales
    // ---------------------------------------
    final fixed = await AppDb.instance.getRunsSuccess('fixed', userId: userId);
    final unlimited = await AppDb.instance.getRunsSuccess(
      'unlimited',
      userId: userId,
    );

    final totalCorrect =
        ((fixed['correct'] ?? 0) as num).toInt() +
        ((unlimited['correct'] ?? 0) as num).toInt();

    final totalSessions =
        ((fixed['runs'] ?? 0) as num).toInt() +
        ((unlimited['runs'] ?? 0) as num).toInt();

    final totalScore = await AppDb.instance.getTotalScoreForUser(userId);
    final newBadgesMessages = <String>[];
    final int bestDayStreak = bestStreak;
    final int currentDayStreak = currentStreak;

    // ---------------------------------------
    // 2) BADGES — réponses correctes cumulées
    // ---------------------------------------

    final msg_correct_10 = await _tryUnlockBadge(
      userId: userId,
      code: 'correct_10',
      title: '10 réponses correctes',
      description: 'Premiers pas 🎯',
      condition: totalCorrect >= 10,
      uiMessage: '🎯 10 réponses correctes — nouveau badge débloqué !',
    );
    if (msg_correct_10 != null) newBadgesMessages.add(msg_correct_10);

    final msg_correct_50 = await _tryUnlockBadge(
      userId: userId,
      code: 'correct_50',
      title: '50 réponses correctes',
      description: 'Tu prends le rythme !',
      condition: totalCorrect >= 50,
      uiMessage: '🏅 50 réponses correctes — nouveau badge débloqué !',
    );
    if (msg_correct_50 != null) newBadgesMessages.add(msg_correct_50);

    final msg_correct_100 = await _tryUnlockBadge(
      userId: userId,
      code: 'correct_100',
      title: '100 réponses correctes',
      description: 'De plus en plus fort·e !',
      condition: totalCorrect >= 100,
      uiMessage: '🏅 100 réponses correctes — nouveau badge débloqué !',
    );
    if (msg_correct_100 != null) newBadgesMessages.add(msg_correct_100);

    final msg_correct_200 = await _tryUnlockBadge(
      userId: userId,
      code: 'correct_200',
      title: '200 réponses correctes',
      description: 'Une puissance grammaticale !',
      condition: totalCorrect >= 200,
      uiMessage: '🥇 200 réponses correctes — incroyable progrès !',
    );
    if (msg_correct_200 != null) newBadgesMessages.add(msg_correct_200);

    final msg_correct_500 = await _tryUnlockBadge(
      userId: userId,
      code: 'correct_500',
      title: '500 réponses correctes',
      description: 'Légende des verbes 💥',
      condition: totalCorrect >= 500,
      uiMessage: '🔥 500 réponses correctes — badge ultra rare débloqué !',
    );
    if (msg_correct_500 != null) newBadgesMessages.add(msg_correct_500);

    // ---------------------------------------
    // 3) BADGES — sessions jouées
    // ---------------------------------------

    final msg_sessions_5 = await _tryUnlockBadge(
      userId: userId,
      code: 'sessions_5',
      title: '5 sessions jouées',
      description: 'Tu t’entraînes régulièrement !',
      condition: totalSessions >= 5,
      uiMessage: '📚 5 sessions jouées — nouveau badge !',
    );
    if (msg_sessions_5 != null) newBadgesMessages.add(msg_sessions_5);

    final msg_sessions_20 = await _tryUnlockBadge(
      userId: userId,
      code: 'sessions_20',
      title: '20 sessions jouées',
      description: 'Une belle habitude !',
      condition: totalSessions >= 20,
      uiMessage: '📘 20 sessions jouées — badge débloqué !',
    );
    if (msg_sessions_20 != null) newBadgesMessages.add(msg_sessions_20);

    final msg_sessions_50 = await _tryUnlockBadge(
      userId: userId,
      code: 'sessions_50',
      title: '50 sessions jouées',
      description: 'Tu es très constant·e !',
      condition: totalSessions >= 50,
      uiMessage: '📗 50 sessions jouées — bravo !',
    );
    if (msg_sessions_50 != null) newBadgesMessages.add(msg_sessions_50);

    // ---------------------------------------
    // 4) RANG GLOBAL — basé sur totalScore
    // ---------------------------------------

    final msg_rank_1 = await _tryUnlockBadge(
      userId: userId,
      code: 'rank_1',
      title: 'Apprenti·e des verbes',
      description: 'Tu débutes ton aventure grammaticale.',
      condition: totalScore >= 1000,
      uiMessage: '📘 Nouveau rang : Apprenti·e des verbes !',
    );
    if (msg_rank_1 != null) newBadgesMessages.add(msg_rank_1);

    final msg_rank_2 = await _tryUnlockBadge(
      userId: userId,
      code: 'rank_2',
      title: 'Conjugueur·se prometteur·se',
      description: 'Ton niveau monte en flèche !',
      condition: totalScore >= 5000,
      uiMessage: '📗 Nouveau rang : Conjugueur·se prometteur·se !',
    );
    if (msg_rank_2 != null) newBadgesMessages.add(msg_rank_2);

    final msg_rank_3 = await _tryUnlockBadge(
      userId: userId,
      code: 'rank_3',
      title: 'Expert·e du français',
      description: 'Tu maîtrises de plus en plus de temps.',
      condition: totalScore >= 15000,
      uiMessage: '📙 Nouveau rang : Expert·e du français !',
    );
    if (msg_rank_3 != null) newBadgesMessages.add(msg_rank_3);

    final msg_rank_4 = await _tryUnlockBadge(
      userId: userId,
      code: 'rank_4',
      title: 'Maître des conjugaisons',
      description: 'Une maîtrise exceptionnelle !',
      condition: totalScore >= 30000,
      uiMessage: '📕 Nouveau rang : Maître des conjugaisons !',
    );
    if (msg_rank_4 != null) newBadgesMessages.add(msg_rank_4);

    final msg_rank_5 = await _tryUnlockBadge(
      userId: userId,
      code: 'rank_5',
      title: 'Grand Sage de la Langue Française',
      description: 'Le rang ultime. Respect éternel.',
      condition: totalScore >= 50000,
      uiMessage: '📚✨ Nouveau rang : Grand Sage de la Langue Française !',
    );
    if (msg_rank_5 != null) newBadgesMessages.add(msg_rank_5);

    // -----------------------------------------
    // 5) Badges : streaks de jours consécutifs
    // -----------------------------------------

    // 3 jours d’affilée
    final msg_streak_3 = await _tryUnlockBadge(
      userId: userId,
      code: 'streak_3',
      title: '🔥 Petit feu',
      description: 'Tu as joué 3 jours de suite. La flamme est allumée 🔥',
      condition: bestDayStreak >= 3,
      uiMessage:
          '🔥 Nouveau badge : "Petit feu" (streak de 3 jours consécutifs).',
    );
    if (msg_streak_3 != null) newBadgesMessages.add(msg_streak_3);

    // 7 jours d’affilée
    final msg_streak_7 = await _tryUnlockBadge(
      userId: userId,
      code: 'streak_7',
      title: '📅 Une semaine complète',
      description:
          'Tu as joué 7 jours d\'affilée. Une semaine entière de conjugaison 👏',
      condition: bestDayStreak >= 7,
      uiMessage:
          '📅 Nouveau badge : "Une semaine complète" (streak de 7 jours).',
    );
    if (msg_streak_7 != null) newBadgesMessages.add(msg_streak_7);

    // 14 jours d’affilée
    final msg_streak_14 = await _tryUnlockBadge(
      userId: userId,
      code: 'streak_14',
      title: '⏳ Deux semaines disciplinées',
      description: '14 jours d\'affilée. Ta discipline fait peur aux verbes 😎',
      condition: bestDayStreak >= 14,
      uiMessage:
          '⏳ Nouveau badge : "Deux semaines disciplinées" (streak de 14 jours).',
    );
    if (msg_streak_14 != null) newBadgesMessages.add(msg_streak_14);

    // 30 jours d’affilée
    final msg_streak_30 = await _tryUnlockBadge(
      userId: userId,
      code: 'streak_30',
      title: '🌟 Machine à conjugaison',
      description:
          '30 jours de suite. On ne sait plus si c\'est toi ou l\'app qui t\'utilise.',
      condition: bestDayStreak >= 30,
      uiMessage:
          '🌟 Nouveau badge : "Machine à conjugaison" (streak de 30 jours).',
    );
    if (msg_streak_30 != null) newBadgesMessages.add(msg_streak_30);

    // 90 jours d’affilée
    final msg_streak_90 = await _tryUnlockBadge(
      userId: userId,
      code: 'streak_90',
      title: '👑 Roi/Reine des verbes',
      description: '90 jours consécutifs. À ce stade, tu ES la conjugaison.',
      condition: bestDayStreak >= 90,
      uiMessage:
          '👑 Nouveau badge : "Roi/Reine des verbes" (streak de 90 jours).',
    );
    if (msg_streak_90 != null) newBadgesMessages.add(msg_streak_90);

    return newBadgesMessages;
  }

  Future<void> startNewRound() async {
    _score = 0;
    correctCount = 0;
    _askedCount = 0;
    _sessionStart = DateTime.now();
    questionStreak = 0;
    bestQuestionStreak = 0;
    await nextExercise();
  }

  // ------------------------------------------------------
  // 14) Streaks journaliers
  // ------------------------------------------------------

  DateTime _dateOnly(DateTime dt) {
    return DateTime(dt.year, dt.month, dt.day);
  }

  bool _sameDay(DateTime a, DateTime b) {
    return a.year == b.year && a.month == b.month && a.day == b.day;
  }

  Future<void> refreshStreaks() async {
    if (_userId == null) {
      currentStreak = 0;
      bestStreak = 0;
      notifyListeners();
      return;
    }

    final s = await AppDb.instance.getStreakForUser(_userId!);
    currentStreak = s['current'] ?? 0;
    bestStreak = s['best'] ?? 0;
    notifyListeners();
  }

  // ------------------------------------------------------
  // 15) OUTILS pour VerbListPage (tout lefff)
  // ------------------------------------------------------

  /// Tous les verbes connus par lefff.
  List<String> getAllVerbs() {
    final list = _lefff.keys.toList();
    list.sort((a, b) => a.compareTo(b));
    return list;
  }

  /// Nom de groupe pour VerbListPage.
  String groupLabelForVerb(String verb) {
    if (_grammarModel != null &&
        _grammarModel!.containsKey('verb_families') &&
        _grammarModel!.containsKey('groups')) {
      final families = (_grammarModel!['verb_families'] as Map)
          .cast<String, dynamic>();
      final groups = (_grammarModel!['groups'] as Map).cast<String, dynamic>();

      for (final entry in families.entries) {
        final key = entry.key;
        final verbs = List<String>.from(entry.value as List);
        if (verbs.contains(verb)) {
          final meta = groups[key] as Map<String, dynamic>?;
          return meta?['name'] as String? ?? key;
        }
      }
    }

    if (verb.endsWith('er')) return '1er groupe';
    if (verb.endsWith('ir')) return '2e groupe';
    return '3e groupe';
  }

  /// Toutes les conjugaisons (pour les temps supportés) d’un verbe via lefff.
  Map<String, Map<String, String>> getAllConjugationsForVerb(String verb) {
    if (_lefff.isEmpty) return {};
    final raw = _lefff[verb];
    if (raw is! Map) return {};
    final verbTenses = raw.cast<String, dynamic>();

    final result = <String, Map<String, String>>{};

    // on parcourt les temps supportés (cycle + expert)
    for (final tense in kAllSupportedTenses) {
      final forms = _buildFormsFor(
        verb: verb,
        tense: tense,
        verbTenses: verbTenses,
      );
      if (forms.isEmpty) continue;

      final formsMap = <String, String>{};
      final max = forms.length.clamp(0, _persons.length);
      for (int i = 0; i < max; i++) {
        final form = forms[i].trim();
        if (form.isEmpty || form == 'NA') continue;
        formsMap[_persons[i]] = form;
      }

      if (formsMap.isNotEmpty) {
        result[tense.label] = formsMap;
      }
    }

    return result;
  }
}
