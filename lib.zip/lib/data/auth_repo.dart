// lib/data/auth_repo.dart
import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'app_db.dart';

/// Gère la connexion et l'inscription des utilisateurs
class AuthRepo {
  AuthRepo._();
  static final AuthRepo instance = AuthRepo._();

  static const String _prefOnlineSync = 'online_sync_enabled';

  /// Créer un compte
  Future<void> signUp(String email, String password) async {
    final db = AppDb.instance;
    final salt = _randomSalt(16);
    final hash = sha256.convert(utf8.encode('$salt$password')).toString();

    final existing = await db.getUserByEmail(email);
    if (existing != null) {
      throw Exception('Un compte existe déjà avec cet email.');
    }

    final id = await db.insertUser(
      email: email,
      passwordHash: hash,
      salt: salt,
      displayName: email.split('@').first,
    );

    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('current_user_id', id);
    await prefs.setString('user_display_name', email.split('@').first);

    // Après création de compte, on tente une synchro
    await syncCustomSetsIfOnline();
  }

  /// Connexion existante
  Future<void> signIn(String email, String password) async {
    final user = await AppDb.instance.getUserByEmail(email);
    if (user == null) throw Exception('Compte introuvable.');

    final salt = user['salt'] as String? ?? '';
    final hash = sha256.convert(utf8.encode('$salt$password')).toString();

    if (hash != user['password_hash']) {
      throw Exception('Mot de passe incorrect.');
    }

    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('current_user_id', user['id'] as int);
    await prefs.setString(
      'user_display_name',
      user['display_name'] ?? email.split('@').first,
    );

    // Après connexion, on tente une synchro
    await syncCustomSetsIfOnline();
  }

  /// Déconnexion
  Future<void> signOut() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('current_user_id');
    await prefs.remove('user_display_name');
  }

  /// Retourne l'utilisateur connecté (ou null)
  Future<Map<String, dynamic>?> getCurrentUser() async {
    final prefs = await SharedPreferences.getInstance();
    final id = prefs.getInt('current_user_id');
    if (id == null) return null;
    return AppDb.instance.getUserById(id);
  }

  /// Retourne juste l'id de l'utilisateur courant (ou null)
  Future<int?> getCurrentUserId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt('current_user_id');
  }

  /// Active / désactive l’option de synchro "en ligne"
  ///
  /// (tu pourras brancher ça sur un switch dans les paramètres)
  Future<void> setOnlineSyncEnabled(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_prefOnlineSync, enabled);
  }

  /// Indique si la synchro en ligne est activée
  Future<bool> isOnlineSyncEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_prefOnlineSync) ?? false;
  }

  /// Tente de synchroniser les CustomSet locaux **si** :
  /// - un utilisateur est connecté
  /// - la synchro en ligne est activée
  ///
  /// Pour l’instant : on simule un serveur en
  /// marquant simplement les ensembles comme synchro
  /// avec un remote_id factice.
  Future<void> syncCustomSetsIfOnline() async {
    final enabled = await isOnlineSyncEnabled();
    if (!enabled) {
      return;
    }

    final currentUser = await getCurrentUser();
    if (currentUser == null) {
      // pas connecté -> pas de synchro
      return;
    }

    // Récupérer les ensembles à synchroniser
    final setsToSync = await AppDb.instance.getCustomSetsToSync();
    if (setsToSync.isEmpty) {
      return;
    }

    // Pour l’instant, on simule un backend :
    // - si remote_id est null, on lui donne "local_<id>"
    // - on met updated_at = maintenant
    // - needs_sync = 0
    final now = DateTime.now();

    for (final set in setsToSync) {
      if (set.id == null) continue;

      final remoteId = set.remoteId ?? 'local_${set.id}';

      await AppDb.instance.markCustomSetSynced(
        localId: set.id!,
        remoteId: remoteId,
        remoteUpdatedAt: now,
      );
    }

    // Plus tard, tu pourras remplacer cette boucle par
    // des appels HTTP réels (POST/PUT/GET) vers ton API.
  }

  String _randomSalt(int len) {
    const chars =
        'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    final r = Random.secure();
    return List.generate(len, (_) => chars[r.nextInt(chars.length)]).join();
  }
}
