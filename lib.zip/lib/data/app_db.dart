import 'dart:convert';
import 'dart:io' show Platform;
import 'package:flutter/services.dart' show rootBundle;
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart' as sqflite;
import 'package:sqflite_common_ffi/sqflite_ffi.dart' as ffi;
import 'package:shared_preferences/shared_preferences.dart';
import '../models/custom_set.dart';

class AppDb {
  AppDb._();
  static final AppDb instance = AppDb._();
  static sqflite.Database? _db;

  Future<sqflite.Database> get database async => _db ??= await _open();

  /// Compare deux DateTime en ignorant l'heure, pour calculer un nombre de
  /// jours calendaires écoulés plutôt qu'une durée brute en heures/ms.
  /// Ex: lundi 23h59 → mardi 00h01 donne 1 jour, même si la différence
  /// réelle n'est que de 2 minutes.
  int _calendarDayDiff(DateTime from, DateTime to) {
    final fromDate = DateTime(from.year, from.month, from.day);
    final toDate = DateTime(to.year, to.month, to.day);
    return toDate.difference(fromDate).inDays;
  }

  Future<sqflite.Database> _open() async {
    if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
      ffi.sqfliteFfiInit();
      sqflite.databaseFactory = ffi.databaseFactoryFfi;
    }

    final path = p.join(await sqflite.getDatabasesPath(), 'conjufun.db');
    return sqflite.openDatabase(
      path,
      version: 11,
      onCreate: (db, v) async {
        // --- USERS ---------------------------------------------------------
        await db.execute('''
          CREATE TABLE users(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          email TEXT NOT NULL UNIQUE,
          password_hash TEXT NOT NULL,
          salt TEXT NOT NULL,
          display_name TEXT,
          has_done_level_test INTEGER NOT NULL DEFAULT 0,
          last_recommended_level TEXT,
          current_streak INTEGER NOT NULL DEFAULT 0,
          best_streak INTEGER NOT NULL DEFAULT 0,
          last_streak_ms INTEGER
        );
        ''');

        // --- VERBS ---------------------------------------------------------
        await db.execute('''
          CREATE TABLE verbs(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            verb TEXT NOT NULL,
            pronoun TEXT NOT NULL,
            tense TEXT NOT NULL,
            correct_answer TEXT NOT NULL
          );
        ''');

        // --- STATS ---------------------------------------------------------
        await db.execute('''
          CREATE TABLE stats(
            tense TEXT,
            correct_count INTEGER DEFAULT 0,
            wrong_count INTEGER DEFAULT 0,
            user_id INTEGER,
            PRIMARY KEY (tense, user_id),
            FOREIGN KEY (user_id) REFERENCES users(id)
          );
        ''');

        // --- RUNS ------------------------------------------
        await db.execute('''
          CREATE TABLE runs(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            started_at INTEGER NOT NULL,
            mode TEXT NOT NULL,
            level TEXT NOT NULL,
            total_target INTEGER NOT NULL,
            correct_count INTEGER NOT NULL,
            score INTEGER NOT NULL,
            user_id INTEGER,
            FOREIGN KEY (user_id) REFERENCES users(id)
          );
        ''');

        // --- BADGES --------------------------------------------------------
        await db.execute('''
          CREATE TABLE badges(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            code TEXT NOT NULL,
            title TEXT NOT NULL,
            description TEXT,
            earned_at INTEGER NOT NULL,
            UNIQUE(user_id, code),
            FOREIGN KEY (user_id) REFERENCES users(id)
          );
        ''');

        // --- CUSTOM SETS (mode créateur) ----------------------------------
        await db.execute('''
          CREATE TABLE custom_sets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            school_level TEXT,
            tenses_json TEXT NOT NULL,
            verbs_json TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            updated_at INTEGER NOT NULL,
            max_questions INTEGER,
            remote_id TEXT,
            needs_sync INTEGER NOT NULL DEFAULT 0,
            is_deleted INTEGER NOT NULL DEFAULT 0,
            deleted_at INTEGER
          );
        ''');

        // Index pour le dashboard ---------------
        await db.execute(
          'CREATE INDEX IF NOT EXISTS idx_runs_user_mode ON runs(user_id, mode);',
        );
        await db.execute(
          'CREATE INDEX IF NOT EXISTS idx_runs_level ON runs(level);',
        );
        await db.execute(
          'CREATE INDEX IF NOT EXISTS idx_runs_started ON runs(started_at DESC);',
        );

        await _importLefffConjugationsJson(db);
      },
      onUpgrade: (db, oldV, newV) async {
        if (oldV < 2) {
          await db.execute('''
            CREATE TABLE IF NOT EXISTS stats(
              tense TEXT,
              correct_count INTEGER DEFAULT 0,
              wrong_count INTEGER DEFAULT 0,
              user_id INTEGER,
              PRIMARY KEY (tense, user_id),
              FOREIGN KEY (user_id) REFERENCES users(id)
            );
          ''');
        }

        if (oldV < 3) {
          await db.execute('''
            CREATE TABLE IF NOT EXISTS runs(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              started_at INTEGER NOT NULL,
              mode TEXT NOT NULL,
              level TEXT NOT NULL,
              total_target INTEGER NOT NULL,
              correct_count INTEGER NOT NULL,
              score INTEGER NOT NULL
            );
          ''');
        }
        if (oldV < 4) {
          await db.execute('''
            CREATE TABLE IF NOT EXISTS users(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              email TEXT NOT NULL UNIQUE,
              password_hash TEXT NOT NULL,
              salt TEXT NOT NULL,
              display_name TEXT
            );
          ''');
        }
        if (oldV < 5) {
          // Ajouter user_id à runs + index
          await db.execute('ALTER TABLE runs ADD COLUMN user_id INTEGER;');
          await db.execute(
            'CREATE INDEX IF NOT EXISTS idx_runs_user_mode ON runs(user_id, mode);',
          );
          await db.execute(
            'CREATE INDEX IF NOT EXISTS idx_runs_level ON runs(level);',
          );
          await db.execute(
            'CREATE INDEX IF NOT EXISTS idx_runs_started ON runs(started_at DESC);',
          );
        }
        if (oldV < 6) {
          // Table badges
          await db.execute('''
          CREATE TABLE IF NOT EXISTS badges(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            code TEXT NOT NULL,
            title TEXT NOT NULL,
            description TEXT,
            earned_at INTEGER NOT NULL,
            UNIQUE(user_id, code),
            FOREIGN KEY (user_id) REFERENCES users(id)
          );
        ''');
        }
        if (oldV < 7) {
          await db.execute(
            'ALTER TABLE users ADD COLUMN has_done_level_test INTEGER NOT NULL DEFAULT 0;',
          );
          await db.execute(
            'ALTER TABLE users ADD COLUMN last_recommended_level TEXT;',
          );
        }
        if (oldV < 8) {
          await db.execute('''
            CREATE TABLE IF NOT EXISTS custom_sets (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              name TEXT NOT NULL,
              school_level TEXT,
              tenses_json TEXT NOT NULL,
              verbs_json TEXT NOT NULL,
              created_at INTEGER NOT NULL
            );
          ''');
        }
        if (oldV < 9) {
          // Colonne manquante possible sur des anciennes installations
          await db.execute(
            'ALTER TABLE custom_sets ADD COLUMN max_questions INTEGER',
          );

          await db.execute(
            'ALTER TABLE custom_sets ADD COLUMN updated_at INTEGER',
          );
          await db.execute('ALTER TABLE custom_sets ADD COLUMN remote_id TEXT');
          await db.execute(
            'ALTER TABLE custom_sets ADD COLUMN needs_sync INTEGER NOT NULL DEFAULT 0',
          );

          // Initialiser updated_at = created_at pour les anciennes lignes
          await db.execute(
            'UPDATE custom_sets SET updated_at = created_at WHERE updated_at IS NULL',
          );
        }

        if (oldV < 10) {
          await db.execute(
            'ALTER TABLE custom_sets ADD COLUMN is_deleted INTEGER NOT NULL DEFAULT 0',
          );
          await db.execute(
            'ALTER TABLE custom_sets ADD COLUMN deleted_at INTEGER',
          );
        }
        if (oldV < 11) {
          await db.execute(
            'ALTER TABLE users ADD COLUMN current_streak INTEGER NOT NULL DEFAULT 0;',
          );
          await db.execute(
            'ALTER TABLE users ADD COLUMN best_streak INTEGER NOT NULL DEFAULT 0;',
          );
          await db.execute(
            'ALTER TABLE users ADD COLUMN last_streak_ms INTEGER;',
          );
        }
      },
    );
  }

  Future<void> _importLefffConjugationsJson(sqflite.Database db) async {
    final raw = await rootBundle.loadString(
      'assets/data/lefff_conjugations.json',
    );
    final Map<String, dynamic> data = json.decode(raw);
    const persons = ['je', 'tu', 'il', 'nous', 'vous', 'ils'];

    final tenseNames = <String, String>{
      'P': 'présent',
      'I': 'imparfait',
      'F': 'futur simple',
      'C': 'conditionnel présent',
      'S': 'subjonctif présent',
      'T': 'subjonctif imparfait',
      'J': 'passé simple',
      'Y': 'impératif',
      'G': 'gérondif',
      'K': 'participe passé',
      'W': 'infinitif',
      'PC': 'passé composé',
      'FP': 'futur proche',
    };

    final batch = db.batch();
    data.forEach((infinitif, tensesAny) {
      final tenses = (tensesAny as Map).cast<String, dynamic>();
      tenses.forEach((tenseCode, formsAny) {
        final tense = tenseNames[tenseCode];
        if (tense == null) return;
        if (formsAny is List) {
          for (var i = 0; i < formsAny.length && i < 6; i++) {
            final form = formsAny[i]?.toString().trim();
            if (form == null || form.isEmpty || form == 'NA') continue;
            batch.insert('verbs', {
              'verb': infinitif,
              'tense': tense,
              'pronoun': persons[i],
              'correct_answer': form,
            });
          }
        }
      });
    });
    await batch.commit(noResult: true);
  }

  // -----------------------------------------------------------------------
  // USERS API
  // -----------------------------------------------------------------------

  Future<int> insertUser({
    required String email,
    required String passwordHash,
    required String salt,
    String? displayName,
  }) async {
    final db = await database;
    return db.insert('users', {
      'email': email.trim().toLowerCase(),
      'password_hash': passwordHash,
      'salt': salt,
      'display_name': displayName,
    }, conflictAlgorithm: sqflite.ConflictAlgorithm.abort);
  }

  Future<Map<String, dynamic>?> getUserByEmail(String email) async {
    final db = await database;
    final rows = await db.query(
      'users',
      where: 'email = ?',
      whereArgs: [email.trim().toLowerCase()],
      limit: 1,
    );
    return rows.isEmpty ? null : rows.first;
  }

  Future<Map<String, dynamic>?> getUserById(int id) async {
    final db = await database;
    final rows = await db.query(
      'users',
      where: 'id = ?',
      whereArgs: [id],
      limit: 1,
    );
    return rows.isEmpty ? null : rows.first;
  }

  Future<void> setUserLevelTestResult({
    required int userId,
    required String levelString,
  }) async {
    final db = await database;
    await db.update(
      'users',
      {'has_done_level_test': 1, 'last_recommended_level': levelString},
      where: 'id = ?',
      whereArgs: [userId],
    );
  }

  Future<Map<String, dynamic>?> getUserLevelTestResult(int userId) async {
    final db = await database;
    final rows = await db.query(
      'users',
      columns: ['has_done_level_test', 'last_recommended_level'],
      where: 'id = ?',
      whereArgs: [userId],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return rows.first;
  }

  // -----------------------------------------------------------------------
  // VERBS / EXERCISES
  // -----------------------------------------------------------------------

  Future<Map<String, dynamic>?> getRandomExerciseRaw() async {
    final db = await database;
    final r = await db.rawQuery('''
      SELECT * FROM verbs 
      WHERE tense NOT IN ('infinitif', 'participe passé', 'gérondif')
      ORDER BY RANDOM()
      LIMIT 1
    ''');
    return r.isEmpty ? null : r.first;
  }

  // -----------------------------------------------------------------------
  // STATS (par temps)
  // -----------------------------------------------------------------------

  Future<void> incrementStat(
    String tense, {
    required bool correct,
    required int userId,
  }) async {
    final db = await database;

    // on essaie de récupérer la ligne existante
    final existing = await db.query(
      'stats',
      where: 'tense = ? AND user_id = ?',
      whereArgs: [tense, userId],
    );

    if (existing.isEmpty) {
      // création nouvelle entrée
      await db.insert('stats', {
        'tense': tense,
        'user_id': userId,
        'correct_count': correct ? 1 : 0,
        'wrong_count': correct ? 0 : 1,
      });
    } else {
      final row = existing.first;
      final correctCount = (row['correct_count'] as int) + (correct ? 1 : 0);
      final wrongCount = (row['wrong_count'] as int) + (correct ? 0 : 1);
      await db.update(
        'stats',
        {'correct_count': correctCount, 'wrong_count': wrongCount},
        where: 'tense = ? AND user_id = ?',
        whereArgs: [tense, userId],
      );
    }
  }

  Future<List<Map<String, dynamic>>> getAllStats() async {
    final db = await database;
    return db.query('stats');
  }

  Future<List<Map<String, dynamic>>> getStatsByTense({int? userId}) async {
    final db = await database;

    if (userId == null) {
      // Stats invité uniquement (user_id IS NULL), pas celles de
      // tous les utilisateurs confondus.
      final rows = await db.rawQuery('''
        SELECT 
          tense,
          SUM(correct_count) AS correct,
          SUM(wrong_count)   AS wrong
        FROM stats
        WHERE user_id IS NULL
        GROUP BY tense
        ORDER BY tense
      ''');
      return rows.map((e) => Map<String, dynamic>.from(e)).toList();
    } else {
      final rows = await db.rawQuery(
        '''
        SELECT 
          tense,
          SUM(correct_count) AS correct,
          SUM(wrong_count)   AS wrong
        FROM stats
        WHERE user_id = ?
        GROUP BY tense
        ORDER BY tense
      ''',
        [userId],
      );
      return rows.map((e) => Map<String, dynamic>.from(e)).toList();
    }
  }

  /// Si userId est fourni, retourne les stats globales pour cet utilisateur
  /// uniquement. Si userId est omis, retourne les stats invité (user_id
  /// NULL) — jamais celles de tous les utilisateurs confondus.
  Future<Map<String, num>> getGlobalStats({int? userId}) async {
    final db = await database;
    final result = userId == null
        ? await db.rawQuery(
            'SELECT SUM(correct_count) AS correct, SUM(wrong_count) AS wrong FROM stats WHERE user_id IS NULL',
          )
        : await db.rawQuery(
            'SELECT SUM(correct_count) AS correct, SUM(wrong_count) AS wrong FROM stats WHERE user_id = ?',
            [userId],
          );
    if (result.isEmpty) return {'correct': 0, 'wrong': 0};
    final row = result.first;
    return {
      'correct': (row['correct'] as int?) ?? 0,
      'wrong': (row['wrong'] as int?) ?? 0,
    };
  }

  // -----------------------------------------------------------------------
  // RUNS
  // -----------------------------------------------------------------------

  Future<void> insertRun({
    required DateTime startedAt,
    required String mode,
    required String level,
    required int totalTarget,
    required int correctCount,
    required int score,
    int? userId,
  }) async {
    final db = await database;
    final startedAtMs = startedAt.millisecondsSinceEpoch;

    if (userId == null) {
      final sp = await SharedPreferences.getInstance();
      final existing = sp.getInt('guest_session_start_ms');

      if (existing == null) {
        await sp.setInt('guest_session_start_ms', startedAtMs);
      }
    }

    await db.insert('runs', {
      'started_at': startedAtMs,
      'mode': mode,
      'level': level,
      'total_target': totalTarget,
      'correct_count': correctCount,
      'score': score,
      'user_id': userId,
    });
  }

  Future<int> getUnlimitedRecord({int? userId}) async {
    final db = await database;
    final List<Map<String, Object?>> r = userId == null
        ? await db.rawQuery(
            "SELECT MAX(score) AS best FROM runs WHERE mode = 'unlimited'",
          )
        : await db.rawQuery(
            "SELECT MAX(score) AS best FROM runs WHERE mode = 'unlimited' AND user_id = ?",
            [userId],
          );
    final row = r.isNotEmpty ? r.first : null;
    return (row?['best'] as int?) ?? 0;
  }

  Future<int> getRecordByLevel(String level, {int? userId}) async {
    final db = await database;
    final r = await db.rawQuery(
      userId == null
          ? "SELECT MAX(score) AS best FROM runs WHERE mode = 'unlimited' AND level = ?"
          : "SELECT MAX(score) AS best FROM runs WHERE mode = 'unlimited' AND level = ? AND user_id = ?",
      userId == null ? [level] : [level, userId],
    );
    final row = r.isNotEmpty ? r.first : null;
    return (row?['best'] as int?) ?? 0;
  }

  Future<int> getRecordByLevelAndMode({
    required String level,
    required String mode,
    int? userId,
  }) async {
    final db = await database;
    final r = await db.rawQuery(
      userId == null
          ? "SELECT MAX(score) AS best FROM runs WHERE mode = ? AND level = ?"
          : "SELECT MAX(score) AS best FROM runs WHERE mode = ? AND level = ? AND user_id = ?",
      userId == null ? [mode, level] : [mode, level, userId],
    );
    final row = r.isNotEmpty ? r.first : null;
    return (row?['best'] as int?) ?? 0;
  }

  Future<List<Map<String, dynamic>>> getRuns({
    required String mode,
    int? userId,
  }) async {
    final db = await database;

    final where = userId == null ? 'mode = ?' : 'mode = ? AND user_id = ?';
    final args = userId == null ? [mode] : [mode, userId];

    final rows = await db.rawQuery('''
    SELECT 
      MIN(id)            AS id,
      started_at,
      mode,
      level,
      MAX(total_target)  AS total_target,
      MAX(correct_count) AS correct_count,
      MAX(score)         AS score,
      user_id
    FROM runs
    WHERE $where
    GROUP BY started_at, mode, level, user_id
    ORDER BY started_at DESC
  ''', args);

    return rows.map((e) => Map<String, dynamic>.from(e)).toList();
  }

  Future<int> getTotalScoreByLevelAndMode({
    required String level,
    required String mode,
    required int? userId,
  }) async {
    if (userId == null) return 0;
    final db = await database;
    final result = await db.rawQuery(
      '''
      SELECT SUM(score) AS total
      FROM runs
      WHERE level = ? AND mode = ? AND user_id = ?
      ''',
      [level, mode, userId],
    );
    if (result.isEmpty) return 0;
    final row = result.first;
    final total = row['total'] as int?;
    return total ?? 0;
  }

  Future<int> getTotalScoreForUser(int? userId) async {
    if (userId == null) return 0;
    final db = await database;
    final result = await db.rawQuery(
      '''
      SELECT SUM(score) AS total
      FROM runs
      WHERE user_id = ?
      ''',
      [userId],
    );
    if (result.isEmpty) return 0;
    final row = result.first;
    final total = row['total'] as int?;
    return total ?? 0;
  }

  Future<int> getTotalScore({required int? userId}) async {
    if (userId == null) {
      final db = await database;
      final result = await db.rawQuery('SELECT SUM(score) AS total FROM runs');
      if (result.isEmpty) return 0;
      final row = result.first;
      return (row['total'] as int?) ?? 0;
    }
    return getTotalScoreForUser(userId);
  }

  Future<Map<String, num>> getRunsSuccess(String mode, {int? userId}) async {
    final db = await database;
    final sql = userId == null
        ? 'SELECT COUNT(*) AS runs, SUM(correct_count) AS correct, SUM(total_target) AS total FROM runs WHERE mode = ?'
        : 'SELECT COUNT(*) AS runs, SUM(correct_count) AS correct, SUM(total_target) AS total FROM runs WHERE mode = ? AND user_id = ?';
    final args = userId == null ? [mode] : [mode, userId];

    final r = await db.rawQuery(sql, args);
    if (r.isEmpty) return {'runs': 0, 'correct': 0, 'total': 0};
    final row = r.first;

    return {
      'runs': (row['runs'] as int?) ?? 0,
      'correct': (row['correct'] as int?) ?? 0,
      'total': (row['total'] as int?) ?? 0,
    };
  }

  // ========================= REWARDS / PROGRESS =========================

  Future<int> getTotalCorrectAnswers(int userId) async {
    final db = await database;
    final rows = await db.rawQuery(
      '''
        SELECT SUM(correct_count) AS total_correct
        FROM runs
        WHERE user_id = ?
      ''',
      [userId],
    );
    final val = rows.first['total_correct'] as num?;
    return (val ?? 0).toInt();
  }

  Future<int> getTotalSessions(int userId) async {
    final db = await database;
    final rows = await db.rawQuery(
      '''
        SELECT COUNT(*) AS cnt
        FROM runs
        WHERE user_id = ?
      ''',
      [userId],
    );
    final val = rows.first['cnt'] as num?;
    return (val ?? 0).toInt();
  }

  Future<List<String>> _getPlayedDays(int userId) async {
    final db = await database;
    final rows = await db.rawQuery(
      '''
        SELECT DISTINCT strftime('%Y-%m-%d', started_at / 1000, 'unixepoch') AS d
        FROM runs
        WHERE user_id = ?
        ORDER BY d DESC
      ''',
      [userId],
    );
    return rows
        .map((r) => (r['d'] as String?) ?? '')
        .where((s) => s.isNotEmpty)
        .toList();
  }

  Future<List<DateTime>> getSessionStartTimesForUser(int userId) async {
    final db = await database;
    final rows = await db.rawQuery(
      '''
    SELECT started_at
    FROM runs
    WHERE user_id = ?
    ORDER BY started_at DESC
    ''',
      [userId],
    );

    return rows
        .map((r) => DateTime.fromMillisecondsSinceEpoch(r['started_at'] as int))
        .toList();
  }

  Future<Map<String, int>> updateStreakAfterSession({
    required int userId,
    required DateTime sessionTime,
  }) async {
    final db = await database;
    final nowMs = sessionTime.millisecondsSinceEpoch;

    return await db.transaction((txn) async {
      final rows = await txn.query(
        'users',
        columns: ['current_streak', 'best_streak', 'last_streak_ms'],
        where: 'id = ?',
        whereArgs: [userId],
        limit: 1,
      );

      if (rows.isEmpty) return {'current': 0, 'best': 0};

      final row = rows.first;
      int current = (row['current_streak'] as int?) ?? 0;
      int best = (row['best_streak'] as int?) ?? 0;
      final int? lastMs = row['last_streak_ms'] as int?;

      if (lastMs == null) {
        // 1ère session qui initialise le streak
        current = 1;
        if (current > best) best = current;

        await txn.update(
          'users',
          {
            'current_streak': current,
            'best_streak': best,
            'last_streak_ms': nowMs,
          },
          where: 'id = ?',
          whereArgs: [userId],
        );
        return {'current': current, 'best': best};
      }

      // BUG CORRIGÉ : l'ancienne logique comparait des fenêtres fixes de
      // 24h/48h en millisecondes (diff < h24, diff < h48), ce qui causait
      // deux problèmes : (1) jouer à 23h59 puis 00h01 le lendemain (2 min
      // d'écart réel) ne comptait pas comme un nouveau jour, et (2) un
      // déphasage progressif d'horaire de jeu pouvait dépasser 48h sans
      // qu'aucun jour calendaire n'ait été sauté. On compare maintenant
      // directement les dates (année/mois/jour), sans tenir compte de
      // l'heure exacte.
      final lastDate = DateTime.fromMillisecondsSinceEpoch(lastMs);
      final dayDiff = _calendarDayDiff(lastDate, sessionTime);

      if (dayDiff <= 0) {
        // Même jour calendaire (ou session antérieure/horloge en arrière) :
        // ne recompte pas, max 1x par jour pour le streak.
        return {'current': current, 'best': best};
      }

      if (dayDiff == 1) {
        // Jour calendaire suivant : streak +1
        current = current <= 0 ? 1 : (current + 1);
      } else {
        // Au moins un jour complet sauté (dayDiff >= 2) : reset, cette
        // session démarre une nouvelle série à 1.
        current = 1;
      }

      if (current > best) best = current;

      await txn.update(
        'users',
        {
          'current_streak': current,
          'best_streak': best,
          'last_streak_ms': nowMs,
        },
        where: 'id = ?',
        whereArgs: [userId],
      );

      return {'current': current, 'best': best};
    });
  }

  Future<Map<String, int>> getStreakForUser(int userId) async {
    final db = await database;
    final rows = await db.query(
      'users',
      columns: ['current_streak', 'best_streak', 'last_streak_ms'],
      where: 'id = ?',
      whereArgs: [userId],
      limit: 1,
    );
    if (rows.isEmpty) return {'current': 0, 'best': 0};

    int current = (rows.first['current_streak'] as int?) ?? 0;
    final int best = (rows.first['best_streak'] as int?) ?? 0;
    final int? lastMs = rows.first['last_streak_ms'] as int?;

    if (lastMs == null) return {'current': current, 'best': best};

    // BUG CORRIGÉ : même problème que dans updateStreakAfterSession, une
    // fenêtre fixe de 48h en millisecondes ne correspond pas à "2 jours
    // calendaires sans jouer". On utilise la même logique de comparaison
    // de dates pour rester cohérent entre les deux fonctions.
    final lastDate = DateTime.fromMillisecondsSinceEpoch(lastMs);
    final dayDiff = _calendarDayDiff(lastDate, DateTime.now());

    if (dayDiff >= 2) {
      // Au moins un jour complet sauté : le streak est expiré.
      await db.update(
        'users',
        {'current_streak': 0},
        where: 'id = ?',
        whereArgs: [userId],
      );
      return {'current': 0, 'best': best};
    }

    return {'current': current, 'best': best};
  }

  Future<List<DateTime>> getActivityDatesForUser(int? userId) async {
    if (userId == null) return [];
    final db = await database;
    final rows = await db.rawQuery(
      '''
        SELECT DISTINCT started_at
        FROM runs
        WHERE user_id = ?
      ''',
      [userId],
    );
    return rows
        .map(
          (r) => DateTime.fromMillisecondsSinceEpoch((r['started_at'] as int)),
        )
        .toList();
  }

  Future<void> attachGuestRunsToUser(int userId) async {
    final db = await database;
    final sp = await SharedPreferences.getInstance();
    final guestSince = sp.getInt('guest_session_start_ms');

    if (guestSince == null) {
      await db.update('runs', {'user_id': userId}, where: 'user_id IS NULL');
    } else {
      await db.update(
        'runs',
        {'user_id': userId},
        where: 'user_id IS NULL AND started_at >= ?',
        whereArgs: [guestSince],
      );
    }

    await sp.remove('guest_session_start_ms');
  }

  Future<bool> userHasBadge(int userId, String code) async {
    final db = await database;
    final rows = await db.query(
      'badges',
      where: 'user_id = ? AND code = ?',
      whereArgs: [userId, code],
      limit: 1,
    );
    return rows.isNotEmpty;
  }

  Future<void> insertBadge({
    required int userId,
    required String code,
    required String title,
    String? description,
  }) async {
    final db = await database;
    final nowMs = DateTime.now().millisecondsSinceEpoch;

    await db.insert('badges', {
      'user_id': userId,
      'code': code,
      'title': title,
      'description': description,
      'earned_at': nowMs,
    }, conflictAlgorithm: sqflite.ConflictAlgorithm.ignore);
  }

  // Pour les badges liés à l'Expert
  Future<bool> userHasPlayedExpert(int userId) async {
    final db = await database;
    final rows = await db.query(
      'runs',
      where: 'user_id = ? AND level = ?',
      whereArgs: [userId, 'expert'],
      limit: 1,
    );
    return rows.isNotEmpty;
  }

  Future<List<Map<String, dynamic>>> getBadgesForUser(int userId) async {
    final db = await database;
    final rows = await db.query(
      'badges',
      where: 'user_id = ?',
      whereArgs: [userId],
      orderBy: 'earned_at DESC',
    );
    return rows;
  }

  Future<List<String>> getDistinctTenses() async {
    final db = await database;
    final rows = await db.rawQuery(
      "SELECT DISTINCT tense FROM verbs ORDER BY tense",
    );
    return rows
        .map((r) => (r['tense'] as String?) ?? '')
        .where((s) => s.isNotEmpty)
        .toList();
  }

  Future<List<String>> getDistinctVerbs() async {
    final db = await database;
    final rows = await db.rawQuery(
      "SELECT DISTINCT verb FROM verbs ORDER BY verb",
    );
    return rows
        .map((r) => (r['verb'] as String?) ?? '')
        .where((s) => s.isNotEmpty)
        .toList();
  }

  Future<Map<String, dynamic>?> getRandomExerciseForCustomSet(
    CustomSet set,
  ) async {
    final db = await database;

    if (set.verbs.isEmpty || set.tenses.isEmpty) {
      return null;
    }

    final verbPlaceholders = List.filled(set.verbs.length, '?').join(',');
    final tensePlaceholders = List.filled(set.tenses.length, '?').join(',');

    final args = <Object?>[...set.verbs, ...set.tenses];

    final rows = await db.rawQuery('''
    SELECT *
    FROM verbs
    WHERE verb IN ($verbPlaceholders)
      AND tense IN ($tensePlaceholders)
    ORDER BY RANDOM()
    LIMIT 1
    ''', args);

    return rows.isEmpty ? null : rows.first;
  }

  // -----------------------------------------------------------------------
  // CUSTOM SETS (mode créateur)
  // -----------------------------------------------------------------------

  Future<int> insertCustomSet(CustomSet set) async {
    final db = await database;
    final now = DateTime.now();

    final toInsert = set.copyWith(
      createdAt: set.createdAt,
      updatedAt: now,
      needsSync: true, // nouvel ensemble -> à synchroniser
    );

    return db.insert('custom_sets', toInsert.toMap());
  }

  Future<List<CustomSet>> getCustomSets() async {
    final db = await database;
    final maps = await db.query(
      'custom_sets',
      where: 'is_deleted = 0',
      orderBy: 'updated_at DESC, created_at DESC',
    );

    return maps.map((m) => CustomSet.fromMap(m)).toList();
  }

  Future<int> deleteCustomSet(int id) async {
    final db = await database;
    final now = DateTime.now().millisecondsSinceEpoch;

    return db.update(
      'custom_sets',
      {
        'is_deleted': 1,
        'deleted_at': now,
        'updated_at': now,
        'needs_sync': 1, // à pousser au serveur
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<int> updateCustomSet(CustomSet set) async {
    final db = await database;
    if (set.id == null) return 0;

    final updated = set.copyWith(
      updatedAt: DateTime.now(),
      needsSync: true, // modification locale -> à resynchroniser
    );

    return db.update(
      'custom_sets',
      updated.toMap(),
      where: 'id = ?',
      whereArgs: [set.id],
    );
  }
  // -----------------------------------------------------------------------
  // SYNCHRO CUSTOM SETS AVEC LE SERVEUR
  // -----------------------------------------------------------------------

  /// Marque un ensemble comme correctement synchronisé avec le serveur.
  ///
  /// - met à jour remote_id (envoyé par le backend)
  /// - met updated_at = horodatage reçu du backend (pour résolution de conflits)
  /// - passe needs_sync = 0
  Future<void> markCustomSetSynced({
    required int localId,
    required String remoteId,
    required DateTime remoteUpdatedAt,
  }) async {
    final db = await database;
    await db.update(
      'custom_sets',
      {
        'remote_id': remoteId,
        'updated_at': remoteUpdatedAt.millisecondsSinceEpoch,
        'needs_sync': 0,
      },
      where: 'id = ?',
      whereArgs: [localId],
    );
  }

  /// Insère ou met à jour un ensemble reçu du serveur.
  ///
  /// Si un custom_set avec le même remote_id existe déjà en local,
  /// on le met à jour. Sinon, on l’insère.
  ///
  /// Retourne l'id local (SQLite).
  Future<int> upsertCustomSetFromRemote(CustomSet remoteSet) async {
    final db = await database;

    if (remoteSet.remoteId == null) {
      throw ArgumentError(
        'remoteSet.remoteId ne doit pas être null dans upsertCustomSetFromRemote',
      );
    }

    // On cherche s’il existe déjà un set avec ce remote_id
    final existing = await db.query(
      'custom_sets',
      where: 'remote_id = ?',
      whereArgs: [remoteSet.remoteId],
      limit: 1,
    );

    // Tout ce qui vient du serveur est considéré comme synchro
    final localModel = remoteSet.copyWith(
      id: null, // id local sera fixé par SQLite
      needsSync: false, // déjà synchronisé
    );

    if (existing.isEmpty) {
      // INSERT
      return db.insert('custom_sets', localModel.toMap());
    } else {
      // UPDATE
      final localId = existing.first['id'] as int;
      await db.update(
        'custom_sets',
        localModel.copyWith(id: localId).toMap(),
        where: 'id = ?',
        whereArgs: [localId],
      );
      return localId;
    }
  }

  Future<List<CustomSet>> getCustomSetsToSync() async {
    final db = await database;

    final rows = await db.query(
      'custom_sets',
      where: 'needs_sync = 1',
      orderBy: 'updated_at ASC, created_at ASC',
    );

    return rows.map((m) => CustomSet.fromMap(m)).toList();
  }
}
