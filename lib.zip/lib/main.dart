import 'package:flutter/material.dart';
import 'pages/root_shell.dart';

// Palette ConjuFun
const brandBlue = Color(0xFF1E40AF);
const brandYellow = Color(0xFFF59E0B);

final RouteObserver<ModalRoute<dynamic>> routeObserver =
    RouteObserver<ModalRoute<dynamic>>();

void main() => runApp(const ConjuFunApp());

class ConjuFunApp extends StatelessWidget {
  const ConjuFunApp({super.key});

  @override
  Widget build(BuildContext context) {
    final baseScheme = ColorScheme.fromSeed(
      seedColor: brandBlue,
      brightness: Brightness.light,
    );
    final scheme = baseScheme.copyWith(
      primary: brandBlue,
      secondary: brandYellow,
      tertiary: brandYellow,
      surfaceTint: brandBlue,
    );

    return MaterialApp(
      debugShowCheckedModeBanner: false, 
      title: 'ConjuFun',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: scheme,
        scaffoldBackgroundColor: const Color(0xFFF7F8FC),
        appBarTheme: AppBarTheme(
          backgroundColor: scheme.surface,
          foregroundColor: scheme.onSurface,
          elevation: 0,
          centerTitle: true,
          titleTextStyle: const TextStyle(
            fontWeight: FontWeight.w800,
            fontSize: 20,
          ),
        ),

        textTheme: const TextTheme(
          headlineSmall: TextStyle(fontWeight: FontWeight.w800),
          titleMedium: TextStyle(fontWeight: FontWeight.w700),
        ),

        cardTheme: CardThemeData(
          elevation: 2,
          clipBehavior: Clip.antiAlias,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          surfaceTintColor: Colors.transparent,
        ),

        chipTheme: ChipThemeData(
          backgroundColor: brandYellow.withOpacity(.20),
          selectedColor: brandYellow.withOpacity(.30),
          labelStyle: const TextStyle(
            color: brandBlue,
            fontWeight: FontWeight.w800,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        ),

        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: scheme.primary,
            foregroundColor: scheme.onPrimary,
            minimumSize: const Size(120, 44),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
            textStyle: const TextStyle(fontWeight: FontWeight.w700),
          ),
        ),

        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            backgroundColor: brandYellow.withOpacity(0.15),
            side: const BorderSide(color: brandYellow, width: 1.5),
            foregroundColor: brandBlue,
            minimumSize: const Size(120, 44),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
            textStyle: const TextStyle(fontWeight: FontWeight.w700),
          ),
        ),

        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          labelStyle: TextStyle(color: scheme.primary.withOpacity(.9)),
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 14,
            vertical: 14,
          ),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: scheme.primary.withOpacity(.25)),
          ),
          focusedBorder: const OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(14)),
            borderSide: BorderSide(color: brandYellow, width: 2),
          ),
        ),

        progressIndicatorTheme: ProgressIndicatorThemeData(
          color: brandYellow,
          linearTrackColor: scheme.primary.withOpacity(.15),
        ),
      ),
      home: const RootShell(),

      navigatorObservers: [routeObserver],
    );
  }
}
