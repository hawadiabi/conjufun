import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show Clipboard, ClipboardData;

import '../data/app_db.dart';
import '../models/custom_set.dart';
import 'edit_custom_set_page.dart';
import 'home_page.dart' show SessionMode;
import '../viewmodels/exercise_vm.dart' as vm;
import 'exercise_page.dart';
import '../main.dart' show brandBlue, brandYellow;

class CreatorHomePage extends StatefulWidget {
  final SessionMode mode;
  final int fixedCount;
  final vm.GameLevel level;

  const CreatorHomePage({
    super.key,
    required this.mode,
    required this.fixedCount,
    required this.level,
  });

  @override
  State<CreatorHomePage> createState() => _CreatorHomePageState();
}

class _CreatorHomePageState extends State<CreatorHomePage> {
  bool _loading = true;
  List<CustomSet> _sets = [];

  @override
  void initState() {
    super.initState();
    _loadSets();
  }

  Future<void> _loadSets() async {
    final sets = await AppDb.instance.getCustomSets();
    setState(() {
      _sets = sets;
      _loading = false;
    });
  }

  Future<void> _deleteSet(CustomSet set) async {
    if (set.id == null) return;
    await AppDb.instance.deleteCustomSet(set.id!);
    await _loadSets();
  }

  // ---------- EXPORT ----------

  Future<void> _exportSet(CustomSet set) async {
    final code = set.exportCode();

    await showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
          title: Text(
            'Code de partage',
            style: const TextStyle(fontWeight: FontWeight.w800),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Ensemble : ${set.name}',
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 8),
              const Text(
                'Copie ce code pour partager l’ensemble.\n'
                'La personne qui le reçoit pourra l’importer dans ConjuFun.',
              ),
              const SizedBox(height: 12),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: const Color(0xFFF3F4FF),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: brandBlue.withOpacity(.25)),
                ),
                child: SelectableText(
                  code,
                  style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
                ),
              ),
            ],
          ),
          actionsPadding: const EdgeInsets.only(right: 12, bottom: 8),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Fermer'),
            ),
            ElevatedButton.icon(
              onPressed: () async {
                await Clipboard.setData(ClipboardData(text: code));
                if (context.mounted) {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Code copié dans le presse-papiers.'),
                    ),
                  );
                }
              },
              icon: const Icon(Icons.copy, size: 18),
              label: const Text('Copier'),
              style: ElevatedButton.styleFrom(
                backgroundColor: brandBlue,
                foregroundColor: Colors.white,
              ),
            ),
          ],
        );
      },
    );
  }

  // ---------- IMPORT ----------

  Future<void> _showImportDialog() async {
    final controller = TextEditingController();

    await showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
          title: const Text('Importer un ensemble'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Colle ici le code de partage (il commence par CFSET1-).',
              ),
              const SizedBox(height: 12),
              TextField(
                controller: controller,
                maxLines: 3,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'CFSET1-...',
                ),
              ),
            ],
          ),
          actionsPadding: const EdgeInsets.only(right: 12, bottom: 8),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Annuler'),
            ),
            ElevatedButton(
              onPressed: () async {
                final code = controller.text.trim();
                if (code.isEmpty) return;

                try {
                final imported = CustomSet.fromShareCode(code);
                final now = DateTime.now();

                final toSave = imported.copyWith(
                  createdAt: now,
                  updatedAt: now,
                  needsSync: true,
                );

                await AppDb.instance.insertCustomSet(toSave);

                  if (!context.mounted) return;
                  Navigator.pop(context);
                  await _loadSets();
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        'Ensemble "${toSave.name}" importé avec succès.',
                      ),
                    ),
                  );
                } on FormatException {
                  if (!context.mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text(
                        'Code invalide. Vérifie qu’il est complet puis réessaie.',
                      ),
                    ),
                  );
                } catch (_) {
                  if (!context.mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text(
                        'Erreur lors de l’import. Réessaie plus tard.',
                      ),
                    ),
                  );
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: brandBlue,
                foregroundColor: Colors.white,
              ),
              child: const Text('Importer'),
            ),
          ],
        );
      },
    );
  }

  // ---------- BUILD ----------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: brandBlue,
        foregroundColor: Colors.white,
        title: const Text('Mode créateur'),
        actions: [
          IconButton(
            icon: const Icon(Icons.download),
            tooltip: 'Importer un ensemble',
            onPressed: _showImportDialog,
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: brandYellow,
        foregroundColor: brandBlue,
        onPressed: () async {
          final changed = await Navigator.of(context).push<bool>(
            MaterialPageRoute(builder: (_) => const EditCustomSetPage()),
          );
          if (changed == true) {
            _loadSets();
          }
        },
        child: const Icon(Icons.add),
      ),
      body: Container(
        color: const Color(0xFFF5F7FF),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 780),
                child: _loading
                    ? const Center(child: CircularProgressIndicator())
                    : Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          // Bandeau d’intro
                          Card(
                            surfaceTintColor: Colors.transparent,
                            elevation: 3,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(18),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(16),
                              child: Row(
                                children: [
                                  Container(
                                    width: 46,
                                    height: 46,
                                    decoration: BoxDecoration(
                                      color: brandYellow.withOpacity(.3),
                                      borderRadius: BorderRadius.circular(16),
                                    ),
                                    child: const Icon(
                                      Icons.auto_fix_high,
                                      color: brandBlue,
                                      size: 26,
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: const [
                                        Text(
                                          'Crée tes propres exercices',
                                          style: TextStyle(
                                            fontSize: 17,
                                            fontWeight: FontWeight.w800,
                                          ),
                                        ),
                                        SizedBox(height: 4),
                                        Text(
                                          'Sélectionne des verbes, des temps et un niveau pour fabriquer des ensembles personnalisés.',
                                          style: TextStyle(fontSize: 13),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 16),

                          // Liste / Empty state
                          Expanded(
                            child: _sets.isEmpty
                                ? Center(
                                    child: Card(
                                      surfaceTintColor: Colors.transparent,
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(18),
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsets.all(20),
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          children: const [
                                            Icon(
                                              Icons.library_add_outlined,
                                              size: 42,
                                              color: brandBlue,
                                            ),
                                            SizedBox(height: 10),
                                            Text(
                                              'Aucun ensemble personnalisé pour le moment.',
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                fontWeight: FontWeight.w700,
                                              ),
                                            ),
                                            SizedBox(height: 6),
                                            Text(
                                              'Appuie sur le bouton + pour créer ton premier ensemble.',
                                              textAlign: TextAlign.center,
                                              style: TextStyle(fontSize: 13),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  )
                                : ListView.separated(
                                    itemCount: _sets.length,
                                    separatorBuilder: (_, __) =>
                                        const SizedBox(height: 10),
                                    itemBuilder: (context, index) {
                                      final set = _sets[index];

                                      final subtitleParts = <String>[];
                                      if (set.schoolLevel != null &&
                                          set.schoolLevel!.trim().isNotEmpty) {
                                        subtitleParts.add(set.schoolLevel!);
                                      }
                                      subtitleParts.add(
                                        '${set.verbs.length} verbes',
                                      );
                                      if (set.tenses.isNotEmpty) {
                                        subtitleParts.add(
                                          set.tenses.join(', '),
                                        );
                                      }

                                      return Card(
                                        elevation: 2,
                                        surfaceTintColor: Colors.transparent,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(
                                            18,
                                          ),
                                        ),
                                        child: InkWell(
                                          borderRadius: BorderRadius.circular(
                                            18,
                                          ),
                                          onTap: () {
                                            Navigator.of(context).push(
                                              MaterialPageRoute(
                                                builder: (_) => ExercisePage(
                                                  mode: widget.mode,
                                                  fixedCount:
                                                      widget.mode ==
                                                          SessionMode.fixed
                                                      ? widget.fixedCount
                                                      : null,
                                                  level: widget.level,
                                                  customSet: set,
                                                ),
                                              ),
                                            );
                                          },
                                          child: Padding(
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 12,
                                              vertical: 10,
                                            ),
                                            child: Row(
                                              children: [
                                                Container(
                                                  width: 40,
                                                  height: 40,
                                                  decoration: BoxDecoration(
                                                    color: brandBlue
                                                        .withOpacity(.12),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                          14,
                                                        ),
                                                  ),
                                                  child: const Icon(
                                                    Icons.layers_outlined,
                                                    color: brandBlue,
                                                  ),
                                                ),
                                                const SizedBox(width: 10),
                                                Expanded(
                                                  child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      Text(
                                                        set.name,
                                                        maxLines: 1,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        style: const TextStyle(
                                                          fontWeight:
                                                              FontWeight.w700,
                                                          fontSize: 15,
                                                        ),
                                                      ),
                                                      const SizedBox(height: 2),
                                                      Text(
                                                        subtitleParts.join(
                                                          ' · ',
                                                        ),
                                                        maxLines: 2,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        style: const TextStyle(
                                                          fontSize: 12,
                                                          color: Colors.black54,
                                                        ),
                                                      ),
                                                      const SizedBox(height: 6),
                                                      Wrap(
                                                        spacing: 6,
                                                        runSpacing: 4,
                                                        children: [
                                                          if (set.schoolLevel !=
                                                              null)
                                                            Chip(
                                                              label: Text(
                                                                set.schoolLevel!,
                                                              ),
                                                              visualDensity:
                                                                  VisualDensity
                                                                      .compact,
                                                              padding:
                                                                  EdgeInsets
                                                                      .zero,
                                                            ),
                                                          Chip(
                                                            label: Text(
                                                              '${set.tenses.length} temps',
                                                            ),
                                                            visualDensity:
                                                                VisualDensity
                                                                    .compact,
                                                            padding:
                                                                EdgeInsets.zero,
                                                          ),
                                                          if (set.maxQuestions !=
                                                                  null &&
                                                              set.maxQuestions! >
                                                                  0)
                                                            Chip(
                                                              label: Text(
                                                                '${set.maxQuestions} questions',
                                                              ),
                                                              visualDensity:
                                                                  VisualDensity
                                                                      .compact,
                                                              padding:
                                                                  EdgeInsets
                                                                      .zero,
                                                            ),
                                                        ],
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                const SizedBox(width: 8),
                                                Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  children: [
                                                    IconButton(
                                                      icon: const Icon(
                                                        Icons.ios_share,
                                                        size: 20,
                                                      ),
                                                      tooltip:
                                                          'Exporter cet ensemble',
                                                      onPressed: () =>
                                                          _exportSet(set),
                                                    ),
                                                    IconButton(
                                                      icon: const Icon(
                                                        Icons
                                                            .delete_outline_rounded,
                                                        size: 20,
                                                      ),
                                                      tooltip: 'Supprimer',
                                                      onPressed: () async {
                                                        final confirm = await showDialog<bool>(
                                                          context: context,
                                                          builder: (ctx) => AlertDialog(
                                                            shape: RoundedRectangleBorder(
                                                              borderRadius:
                                                                  BorderRadius.circular(
                                                                    18,
                                                                  ),
                                                            ),
                                                            title: const Text(
                                                              'Supprimer cet ensemble ?',
                                                            ),
                                                            content: Text(
                                                              '“${set.name}” sera supprimé définitivement.',
                                                            ),
                                                            actions: [
                                                              TextButton(
                                                                onPressed: () =>
                                                                    Navigator.pop(
                                                                      ctx,
                                                                      false,
                                                                    ),
                                                                child:
                                                                    const Text(
                                                                      'Annuler',
                                                                    ),
                                                              ),
                                                              TextButton(
                                                                onPressed: () =>
                                                                    Navigator.pop(
                                                                      ctx,
                                                                      true,
                                                                    ),
                                                                child: const Text(
                                                                  'Supprimer',
                                                                  style: TextStyle(
                                                                    color: Colors
                                                                        .red,
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        );
                                                        if (confirm == true) {
                                                          _deleteSet(set);
                                                        }
                                                      },
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                          ),
                        ],
                      ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
