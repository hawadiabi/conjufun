import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../main.dart' show brandBlue, brandYellow;
import '../data/app_db.dart';

enum BadgeCategory { correctAnswers, sessions, rank, streak }

class BadgeDefinition {
  final String code;
  final String title;
  final String description;
  final BadgeCategory category;
  final String emoji;

  const BadgeDefinition({
    required this.code,
    required this.title,
    required this.description,
    required this.category,
    required this.emoji,
  });
}

// Catalogue complet des badges connus
const List<BadgeDefinition> kBadgeCatalog = [
  // --- BONNES RÉPONSES ---
  BadgeDefinition(
    code: 'correct_10',
    title: '10 réponses correctes',
    description: 'Premiers pas 🎯',
    category: BadgeCategory.correctAnswers,
    emoji: '🎯',
  ),
  BadgeDefinition(
    code: 'correct_50',
    title: '50 réponses correctes',
    description: 'Tu prends le rythme !',
    category: BadgeCategory.correctAnswers,
    emoji: '🏅',
  ),
  BadgeDefinition(
    code: 'correct_100',
    title: '100 réponses correctes',
    description: 'De plus en plus fort·e !',
    category: BadgeCategory.correctAnswers,
    emoji: '🏅',
  ),
  BadgeDefinition(
    code: 'correct_200',
    title: '200 réponses correctes',
    description: 'Une puissance grammaticale !',
    category: BadgeCategory.correctAnswers,
    emoji: '🥇',
  ),
  BadgeDefinition(
    code: 'correct_500',
    title: '500 réponses correctes',
    description: 'Légende des verbes 💥',
    category: BadgeCategory.correctAnswers,
    emoji: '🔥',
  ),

  // --- SESSIONS JOUÉES ---
  BadgeDefinition(
    code: 'sessions_5',
    title: '5 sessions jouées',
    description: 'Tu t’entraînes régulièrement !',
    category: BadgeCategory.sessions,
    emoji: '📚',
  ),
  BadgeDefinition(
    code: 'sessions_20',
    title: '20 sessions jouées',
    description: 'Une belle habitude !',
    category: BadgeCategory.sessions,
    emoji: '📘',
  ),
  BadgeDefinition(
    code: 'sessions_50',
    title: '50 sessions jouées',
    description: 'Tu es très constant·e !',
    category: BadgeCategory.sessions,
    emoji: '📗',
  ),

  // --- RANGS (score cumulé global) ---
  BadgeDefinition(
    code: 'rank_1',
    title: 'Apprenti·e des verbes',
    description: 'Tu débutes ton aventure grammaticale.',
    category: BadgeCategory.rank,
    emoji: '📘',
  ),
  BadgeDefinition(
    code: 'rank_2',
    title: 'Conjugueur·se prometteur·se',
    description: 'Ton niveau monte en flèche !',
    category: BadgeCategory.rank,
    emoji: '📗',
  ),
  BadgeDefinition(
    code: 'rank_3',
    title: 'Expert·e du français',
    description: 'Tu maîtrises de plus en plus de temps.',
    category: BadgeCategory.rank,
    emoji: '📙',
  ),
  BadgeDefinition(
    code: 'rank_4',
    title: 'Maître des conjugaisons',
    description: 'Une maîtrise exceptionnelle !',
    category: BadgeCategory.rank,
    emoji: '📕',
  ),
  BadgeDefinition(
    code: 'rank_5',
    title: 'Grand Sage de la Langue Française',
    description: 'Le rang ultime. Respect éternel.',
    category: BadgeCategory.rank,
    emoji: '📚✨',
  ),

  // --- STREAKS JOURNALIERS (global) ---
  BadgeDefinition(
    code: 'streak_3',
    title: '🔥 Petit feu',
    description: 'Tu as joué 3 jours de suite. La flamme est allumée 🔥',
    category: BadgeCategory.streak,
    emoji: '🔥',
  ),
  BadgeDefinition(
    code: 'streak_7',
    title: '📅 Une semaine complète',
    description:
        'Tu as joué 7 jours d\'affilée. Une semaine entière de conjugaison 👏',
    category: BadgeCategory.streak,
    emoji: '📅',
  ),
  BadgeDefinition(
    code: 'streak_14',
    title: '⏳ Deux semaines disciplinées',
    description: '14 jours d\'affilée. Ta discipline fait peur aux verbes 😎',
    category: BadgeCategory.streak,
    emoji: '⏳',
  ),
  BadgeDefinition(
    code: 'streak_30',
    title: '🌟 Machine à conjugaison',
    description:
        '30 jours de suite. On ne sait plus si c\'est toi ou l\'app qui t\'utilise.',
    category: BadgeCategory.streak,
    emoji: '🌟',
  ),
  BadgeDefinition(
    code: 'streak_90',
    title: '👑 Roi/Reine des verbes',
    description: '90 jours consécutifs. À ce stade, tu ES la conjugaison.',
    category: BadgeCategory.streak,
    emoji: '👑',
  ),
];

// Conditions textuelles pour l’explication “Comment débloquer ?”
String badgeCondition(BadgeDefinition b) {
  switch (b.code) {
    case 'correct_10':
      return 'Répondre correctement à au moins 10 questions.';
    case 'correct_50':
      return 'Répondre correctement à au moins 50 questions.';
    case 'correct_100':
      return 'Répondre correctement à au moins 100 questions.';
    case 'correct_200':
      return 'Répondre correctement à au moins 200 questions.';
    case 'correct_500':
      return 'Répondre correctement à au moins 500 questions.';

    case 'sessions_5':
      return 'Jouer au moins 5 sessions (tous modes confondus).';
    case 'sessions_20':
      return 'Jouer au moins 20 sessions (tous modes confondus).';
    case 'sessions_50':
      return 'Jouer au moins 50 sessions (tous modes confondus).';

    // Rang basé sur le score cumulé global (en points)
    case 'rank_1':
      return 'Atteindre au moins 1 000 pts de score cumulé dans le jeu.';
    case 'rank_2':
      return 'Atteindre au moins 5 000 pts de score cumulé.';
    case 'rank_3':
      return 'Atteindre au moins 15 000 pts de score cumulé.';
    case 'rank_4':
      return 'Atteindre au moins 30 000 pts de score cumulé.';
    case 'rank_5':
      return 'Atteindre au moins 50 000 pts de score cumulé.';

    case 'streak_3':
      return 'Jouer au moins 3 jours consécutifs.';
    case 'streak_7':
      return 'Jouer au moins 7 jours consécutifs.';
    case 'streak_14':
      return 'Jouer au moins 14 jours consécutifs.';
    case 'streak_30':
      return 'Jouer au moins 30 jours consécutifs.';
    case 'streak_90':
      return 'Jouer au moins 90 jours consécutifs.';

    default:
      return 'Continue à jouer et à bien répondre pour débloquer ce badge.';
  }
}

class _RankStep {
  final int minScore;
  final String name;
  const _RankStep(this.minScore, this.name);
}

const List<_RankStep> _rankSteps = [
  _RankStep(0, 'Début du parcours'),
  _RankStep(1000, 'Apprenti·e des verbes'),
  _RankStep(5000, 'Conjugueur·se prometteur·se'),
  _RankStep(15000, 'Expert·e du français'),
  _RankStep(30000, 'Maître des conjugaisons'),
  _RankStep(50000, 'Grand Sage de la Langue Française'),
];

class BadgesPage extends StatefulWidget {
  const BadgesPage({super.key});

  @override
  State<BadgesPage> createState() => _BadgesPageState();
}

class _BadgesPageState extends State<BadgesPage> {
  bool _loading = true;
  Set<String> _unlockedCodes = {};

  // Profil joueur
  int _xp = 0;
  int _level = 1;
  int _globalScore = 0;
  int _streak = 0;
  int _bestStreak = 0;

  @override
  void initState() {
    super.initState();
    _loadBadgesAndProfile();
  }

  Future<void> _loadBadgesAndProfile() async {
    final sp = await SharedPreferences.getInstance();
    final userId = sp.getInt('current_user_id');

    if (userId == null) {
      setState(() {
        _loading = false;
        _unlockedCodes = {};
        _xp = 0;
        _level = 1;
        _globalScore = 0;
        _streak = 0;
      });
      return;
    }

    // --- Badges débloqués ---
    final rows = await AppDb.instance.getBadgesForUser(userId);
    final codes = rows
        .map((row) => (row['code'] as String?) ?? '')
        .where((c) => c.isNotEmpty)
        .toSet();

    // --- Profil joueur (global) ---
    final fixedSummary = await AppDb.instance.getRunsSuccess(
      'fixed',
      userId: userId,
    );
    final unlimitedSummary = await AppDb.instance.getRunsSuccess(
      'unlimited',
      userId: userId,
    );

    final fixedCorrect = (fixedSummary['correct'] as int? ?? 0);
    final unlimitedCorrect = (unlimitedSummary['correct'] as int? ?? 0);
    final totalCorrect = fixedCorrect + unlimitedCorrect;

    final fixedRows = await AppDb.instance.getRuns(
      mode: 'fixed',
      userId: userId,
    );
    final unlimitedRows = await AppDb.instance.getRuns(
      mode: 'unlimited',
      userId: userId,
    );

    final fixedScoreSum = fixedRows.fold<int>(
      0,
      (s, r) => s + ((r['score'] ?? 0) as num).toInt(),
    );
    final unlimitedScoreSum = unlimitedRows.fold<int>(
      0,
      (s, r) => s + ((r['score'] ?? 0) as num).toInt(),
    );

    final globalScore = fixedScoreSum + unlimitedScoreSum;

    // Points / niveau
    final xp = totalCorrect * 10;
    const xpPerLevel = 200;
    final level = 1 + (xp ~/ xpPerLevel);

    // Streak global
    final streak = await AppDb.instance.getStreakForUser(userId);
    final current = streak['current'] ?? 0;
    final best = streak['best'] ?? 0;

    setState(() {
      _unlockedCodes = codes;
      _xp = xp;
      _level = level;
      _globalScore = globalScore;
      _streak = current;
      _bestStreak = best;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Badges'),
        backgroundColor: brandBlue,
        foregroundColor: Colors.white,
        centerTitle: true,
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFFEFF3FF), Color(0xFFF7F8FC)],
                ),
              ),
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
                children: [
                  LayoutBuilder(
                    builder: (context, constraints) {
                      final isWide = constraints.maxWidth >= 720;
                      if (isWide) {
                        return Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: ConstrainedBox(
                                constraints: const BoxConstraints(
                                  maxWidth: 380,
                                ),
                                child: _buildBadgesHeaderCard(),
                              ),
                            ),
                            const SizedBox(width: 16),
                            Expanded(child: _buildPlayerHeader()),
                          ],
                        );
                      } else {
                        return Column(
                          children: [
                            Center(
                              child: ConstrainedBox(
                                constraints: const BoxConstraints(
                                  maxWidth: 380,
                                ),
                                child: _buildBadgesHeaderCard(),
                              ),
                            ),
                            const SizedBox(height: 16),
                            _buildPlayerHeader(),
                          ],
                        );
                      }
                    },
                  ),

                  const SizedBox(height: 20),

                  _buildCategorySection(
                    context,
                    title: 'Badges – réponses correctes',
                    category: BadgeCategory.correctAnswers,
                  ),
                  const SizedBox(height: 16),
                  _buildCategorySection(
                    context,
                    title: 'Badges – sessions jouées',
                    category: BadgeCategory.sessions,
                  ),
                  const SizedBox(height: 16),
                  _buildCategorySection(
                    context,
                    title: 'Badges – rangs atteints',
                    category: BadgeCategory.rank,
                  ),
                  const SizedBox(height: 16),
                  _buildCategorySection(
                    context,
                    title: 'Badges – streaks de jours',
                    category: BadgeCategory.streak,
                  ),
                ],
              ),
            ),
    );
  }

  Widget _buildPlayerHeader() {
    final int score = _globalScore;

    int currentIndex = 0;
    for (var i = 0; i < _rankSteps.length; i++) {
      if (score >= _rankSteps[i].minScore) {
        currentIndex = i;
      }
    }

    final _RankStep currentStep = _rankSteps[currentIndex];
    final bool isMaxRank = currentIndex == _rankSteps.length - 1;

    double progress;
    int remainingPts;
    String progressText;

    if (isMaxRank) {
      progress = 1.0;
      remainingPts = 0;
      progressText =
          'Tu as atteint le rang maximal 🎉 Continue à jouer pour rester au top !';
    } else {
      final _RankStep nextStep = _rankSteps[currentIndex + 1];
      final int span = nextStep.minScore - currentStep.minScore;
      final int gained = score - currentStep.minScore;

      progress = span == 0 ? 0.0 : (gained / span).clamp(0.0, 1.0);
      remainingPts = (nextStep.minScore - score).clamp(0, nextStep.minScore);
      progressText = 'Encore $remainingPts pts avant "${nextStep.name}".';
    }

    return Card(
      elevation: 3,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
        child: LayoutBuilder(
          builder: (context, constraints) {
            final bool isCompact = constraints.maxWidth < 380;

            // --- VERSION COMPACTE (mobile étroit) ---
            if (isCompact) {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CircleAvatar(
                        radius: 22,
                        backgroundColor: brandYellow.withOpacity(.2),
                        child: const Text('🎮', style: TextStyle(fontSize: 24)),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Rang actuel : ${currentStep.name}',
                              style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w900,
                                color: Colors.black87,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Score cumulé : $score pts',
                              style: const TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: Colors.black87,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    'Progression vers le prochain rang',
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 6),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: LinearProgressIndicator(
                      value: progress,
                      minHeight: 8,
                      backgroundColor: brandBlue.withOpacity(.12),
                      valueColor: const AlwaysStoppedAnimation<Color>(
                        brandYellow,
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(progressText, style: const TextStyle(fontSize: 11)),
                  const SizedBox(height: 8),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(.9),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(
                            Icons.local_fire_department,
                            color: Colors.orange,
                            size: 16,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            'Série : $_streak j',
                            style: const TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 11,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              );
            }

            // --- VERSION LARGE (tablette / desktop / mobile large) ---
            return Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CircleAvatar(
                  radius: 26,
                  backgroundColor: brandYellow.withOpacity(.2),
                  child: Text(
                    '🎮',
                    style: Theme.of(context).textTheme.headlineSmall,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Rang actuel : ${currentStep.name}',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                          color: Colors.black87,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Score cumulé : $score pts',
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: Colors.black87,
                        ),
                      ),
                      const SizedBox(height: 10),
                      const Text(
                        'Progression vers le prochain rang',
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 6),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: LinearProgressIndicator(
                          value: progress,
                          minHeight: 10,
                          backgroundColor: brandBlue.withOpacity(.12),
                          valueColor: const AlwaysStoppedAnimation<Color>(
                            brandYellow,
                          ),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(progressText, style: const TextStyle(fontSize: 12)),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                // Streak global
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 6,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(.9),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.local_fire_department,
                        color: Colors.orange,
                        size: 18,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        'Série : $_streak j',
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  // --- Carte "Tes badges" ---
  Widget _buildBadgesHeaderCard() {
    final unlockedCount = _unlockedCodes.length;
    final total = kBadgeCatalog.length;

    return Card(
      elevation: 2,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            CircleAvatar(
              radius: 24,
              backgroundColor: brandYellow.withOpacity(.2),
              child: const Text('🏅', style: TextStyle(fontSize: 26)),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Tes badges',
                    style: Theme.of(context).textTheme.titleMedium!.copyWith(
                      fontWeight: FontWeight.w800,
                      color: brandBlue,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '$unlockedCount / $total débloqués',
                    style: TextStyle(
                      color: Colors.grey[700],
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCategorySection(
    BuildContext context, {
    required String title,
    required BadgeCategory category,
  }) {
    final badges = kBadgeCatalog.where((b) => b.category == category).toList();

    if (badges.isEmpty) return const SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: Theme.of(context).textTheme.titleMedium!.copyWith(
            fontWeight: FontWeight.w800,
            color: brandBlue,
          ),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: badges.map((b) => _buildBadgeCard(context, b)).toList(),
        ),
      ],
    );
  }

  Widget _buildBadgeCard(BuildContext context, BadgeDefinition badge) {
    final unlocked = _unlockedCodes.contains(badge.code);

    final Color baseColor = unlocked ? Colors.white : Colors.grey.shade200;
    final Color borderColor = unlocked
        ? brandYellow.withOpacity(.8)
        : Colors.grey.shade400;
    final Color textColor = unlocked ? Colors.black87 : Colors.grey.shade600;
    final emoji = unlocked ? badge.emoji : '🔒';

    return SizedBox(
      width: 185,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => _showBadgeDetails(badge, unlocked),
        child: Card(
          elevation: unlocked ? 3 : 0,
          color: baseColor,
          surfaceTintColor: Colors.transparent,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: BorderSide(color: borderColor),
          ),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Opacity(
              opacity: unlocked ? 1.0 : 0.6,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(emoji, style: const TextStyle(fontSize: 20)),
                      const Spacer(),
                      if (unlocked)
                        const Icon(
                          Icons.check_circle,
                          size: 18,
                          color: Colors.green,
                        )
                      else
                        const Icon(Icons.lock_outline, size: 18),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    badge.title,
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 13,
                      color: textColor,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    badge.description,
                    style: TextStyle(
                      fontSize: 11,
                      color: textColor.withOpacity(0.8),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _showBadgeDetails(BadgeDefinition badge, bool unlocked) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        final condition = badgeCondition(badge);
        return Padding(
          padding: const EdgeInsets.fromLTRB(20, 14, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Text(badge.emoji, style: const TextStyle(fontSize: 40)),
              ),
              const SizedBox(height: 8),
              Text(
                badge.title,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 6),
              Text(badge.description, style: const TextStyle(fontSize: 13)),
              const SizedBox(height: 12),
              Row(
                children: [
                  Icon(
                    unlocked ? Icons.check_circle : Icons.lock_outline,
                    color: unlocked ? Colors.green : Colors.grey,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    unlocked ? 'Badge débloqué 🎉' : 'Badge verrouillé',
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              const Text(
                'Comment débloquer ce badge ?',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
              ),
              const SizedBox(height: 4),
              Text(condition, style: const TextStyle(fontSize: 13)),
            ],
          ),
        );
      },
    );
  }
}
