import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import '../main.dart' show brandBlue, brandYellow;
import '../viewmodels/exercise_vm.dart' as vm;
import '../config/levels_config.dart'
    show kLevelTenses, kLevelVerbs, kAllSupportedTenses;
import '../data/app_db.dart';
import 'package:shared_preferences/shared_preferences.dart';

// Config interne pour le test de niveau
class _PlacementConfig {
  final vm.GameLevel level;
  final double minSuccessRate;

  const _PlacementConfig(this.level, this.minSuccessRate);
}

// 4 questions par niveau -> 5 niveaux = 20 questions
const Map<vm.GameLevel, int> _questionsPerLevel = {
  vm.GameLevel.level_cycle1: 4,
  vm.GameLevel.level_cycle2: 4,
  vm.GameLevel.level_cycle3: 4,
  vm.GameLevel.level_sec1: 4,
  vm.GameLevel.level_sec2: 4,
};

class _LevelTestQuestionSpec {
  final vm.GameLevel level;
  final vm.Tense tense;

  const _LevelTestQuestionSpec(this.level, this.tense);
}

// Temps qu’on veut ÉVITER dans le test de niveau
const Set<vm.Tense> _forbiddenPlacementTenses = {
  vm.Tense.passeCompose,
  vm.Tense.infinitif,
  vm.Tense.infinitifPasse,
  vm.Tense.gerondif,
  vm.Tense.participePresent,
  vm.Tense.participePasse,
};

// Temps “simples” prioritaires pour le test de niveau
const Set<vm.Tense> _corePlacementTenses = {
  vm.Tense.present,
  vm.Tense.futurProche,
  vm.Tense.imparfait,
  vm.Tense.futur,
  vm.Tense.imperatif,
  vm.Tense.conditionnel,
  vm.Tense.passeSimple,
  vm.Tense.subjonctif,
};

const List<_PlacementConfig> _placementConfigs = [
  _PlacementConfig(vm.GameLevel.level_cycle1, 0.75),
  _PlacementConfig(vm.GameLevel.level_cycle2, 0.75),
  _PlacementConfig(vm.GameLevel.level_cycle3, 0.75),
  _PlacementConfig(vm.GameLevel.level_sec1, 0.75),
  _PlacementConfig(vm.GameLevel.level_sec2, 0.75),
];

bool _needsPronoun(vm.Exercise ex) {
  switch (ex.tense) {
    case vm.Tense.imperatif:
      return false;
    case vm.Tense.infinitif:
    case vm.Tense.infinitifPasse:
    case vm.Tense.gerondif:
    case vm.Tense.participePresent:
    case vm.Tense.participePasse:
      return false;
    default:
      return true;
  }
}

String _normalizePronoun(String p) {
  final v = p.trim().toLowerCase();

  if (v == "j'" || v == 'je') return 'je';

  if (v == 'il' || v == 'elle' || v == 'il/elle') {
    return 'il/elle';
  }

  if (v == 'ils' || v == 'elles' || v == 'ils/elles') {
    return 'ils/elles';
  }

  if (v.isEmpty) return '(aucun pronom)';

  return v;
}

String _personLabel(String pronoun) {
  switch (pronoun.toLowerCase()) {
    case 'je':
    case "j'":
      return '1re personne du singulier';
    case 'tu':
      return '2e personne du singulier';
    case 'il':
    case 'elle':
    case 'il/elle':
      return '3e personne du singulier';
    case 'nous':
      return '1re personne du pluriel';
    case 'vous':
      return '2e personne du pluriel';
    case 'ils':
    case 'elles':
    case 'ils/elles':
      return '3e personne du pluriel';
    case '(aucun pronom)':
      return 'forme sans pronom';
    default:
      return 'personne non spécifiée';
  }
}

String _levelLabel(vm.GameLevel level) {
  switch (level) {
    case vm.GameLevel.level_cycle1:
      return 'Niveau 1 (Cycle 1)';
    case vm.GameLevel.level_cycle2:
      return 'Niveau 2 (Cycle 2)';
    case vm.GameLevel.level_cycle3:
      return 'Niveau 3 (Cycle 3)';
    case vm.GameLevel.level_sec1:
      return 'Niveau 4 (Sec 1)';
    case vm.GameLevel.level_sec2:
      return 'Niveau 5 (Sec 2)';
    case vm.GameLevel.expert:
      return 'Niveau Expert';
  }
}

class LevelTestPage extends StatefulWidget {
  const LevelTestPage({super.key});

  @override
  State<LevelTestPage> createState() => _LevelTestPageState();
}

class _LevelTestPageState extends State<LevelTestPage>
    with SingleTickerProviderStateMixin {
  final vm.ExerciseViewModel _viewModel = vm.ExerciseViewModel();
  final TextEditingController _controller = TextEditingController();

  vm.Exercise? _currentExercise;
  String _feedback = '';
  bool _locked = false;

  bool _isLoading = true;
  bool _isFinished = false;
  vm.GameLevel? _recommendedLevel;

  Completer<bool>? _answerCompleter;
  bool? _lastAnswerCorrect;

  // --- progression ---
  int _totalQuestions = 0;
  int _questionsAsked = 0;

  // --- animation pour le "shake" du TextField en cas d’erreur de saisie ---
  late AnimationController _shakeController;

  double get _progress =>
      _totalQuestions == 0 ? 0.0 : _questionsAsked / _totalQuestions;

  int _computeTotalQuestions() {
    int sum = 0;
    for (final config in _placementConfigs) {
      sum += _buildSpecsForLevel(config.level).length;
    }
    return sum;
  }

  @override
  void initState() {
    super.initState();
    _shakeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 260),
    );
    _startTest();
  }

  @override
  void dispose() {
    _controller.dispose();
    _shakeController.dispose();
    super.dispose();
  }

  Future<void> _startTest() async {
    await _viewModel.initForVerbList();

    _totalQuestions = _computeTotalQuestions();

    setState(() {
      _isLoading = false;
    });

    for (final config in _placementConfigs) {
      final ok = await _runLevel(config.level, config.minSuccessRate);
      if (!ok) {
        // Si l’élève ne réussit pas assez bien ce niveau, on recommande CE niveau-là.
        setState(() {
          _isFinished = true;
          _recommendedLevel = config.level;
          _currentExercise = null;
        });
        return;
      }
    }

    // Si tous les niveaux sont réussis au-dessus des seuils → Expert
    setState(() {
      _isFinished = true;
      _recommendedLevel = vm.GameLevel.expert;
      _currentExercise = null;
    });
  }

  List<_LevelTestQuestionSpec> _buildSpecsForLevel(vm.GameLevel level) {
    // 0) Récupérer les niveaux précédents dans l’ordre de _placementConfigs
    final int currentIndex = _placementConfigs.indexWhere(
      (cfg) => cfg.level == level,
    );

    final List<vm.GameLevel> previousLevels = currentIndex <= 0
        ? const []
        : _placementConfigs.take(currentIndex).map((cfg) => cfg.level).toList();

    // 1) Temps de base pour CE niveau
    List<vm.Tense> baseTenses = List<vm.Tense>.from(
      kLevelTenses[level] ?? const [],
    );

    // 2) Construire l’ensemble des temps déjà “vus” dans les niveaux précédents
    final Set<vm.Tense> previousTenses = {};
    for (final lvl in previousLevels) {
      previousTenses.addAll(kLevelTenses[lvl] ?? const []);
    }

    // 3) Temps spécifiques à ce niveau = ceux qui apparaissent pour la
    //    première fois ici (pas présents dans les niveaux précédents)
    List<vm.Tense> levelTenses = baseTenses
        .where((t) => !previousTenses.contains(t))
        .toList();

    // Si jamais il n’y a rien de “nouveau” (ex: Cycle 3), on retombe sur les temps de base
    if (levelTenses.isEmpty) {
      levelTenses = baseTenses;
    }

    // 4) On enlève les temps “forbidden” du test de niveau
    levelTenses.removeWhere((t) => _forbiddenPlacementTenses.contains(t));

    if (levelTenses.isEmpty) {
      levelTenses = baseTenses
          .where((t) => !_forbiddenPlacementTenses.contains(t))
          .toList();
    }

    // 5) On sépare : temps “core” (importants) vs autres
    final List<vm.Tense> core = levelTenses
        .where((t) => _corePlacementTenses.contains(t))
        .toList();
    final List<vm.Tense> others = levelTenses
        .where((t) => !_corePlacementTenses.contains(t))
        .toList();

    core.shuffle();
    others.shuffle();

    // 6) Combien de questions pour ce niveau ?
    final int targetCount = _questionsPerLevel[level] ?? 2;

    final List<_LevelTestQuestionSpec> specs = [];

    for (final t in core) {
      if (specs.length >= targetCount) break;
      specs.add(_LevelTestQuestionSpec(level, t));
    }

    for (final t in others) {
      if (specs.length >= targetCount) break;
      specs.add(_LevelTestQuestionSpec(level, t));
    }

    // 7) S’il manque encore des questions, on recycle dans levelTenses
    int i = 0;
    while (specs.length < targetCount && levelTenses.isNotEmpty) {
      specs.add(
        _LevelTestQuestionSpec(level, levelTenses[i % levelTenses.length]),
      );
      i++;
    }

    specs.shuffle();
    return specs;
  }

  Future<bool> _runLevel(vm.GameLevel level, double minSuccessRate) async {
    final specs = _buildSpecsForLevel(level);

    int correct = 0;
    int total = 0;

    for (final spec in specs) {
      final ex = await _viewModel.generateExerciseForLevelAndTense(
        spec.level,
        spec.tense,
      );
      if (ex == null) continue;

      final isCorrect = await _askQuestion(ex);
      total++;
      if (isCorrect) correct++;
    }

    final rate = total == 0 ? 0.0 : correct / total;
    return rate >= minSuccessRate;
  }

  Future<bool> _askQuestion(vm.Exercise ex) async {
    setState(() {
      _currentExercise = ex;
      _feedback = '';
      _locked = false;
      _controller.clear();
      _lastAnswerCorrect = null;
      _questionsAsked++;
    });

    _answerCompleter = Completer<bool>();
    return _answerCompleter!.future;
  }

  Future<void> _onNextQuestionPressed() async {
    if (_answerCompleter == null || _answerCompleter!.isCompleted) return;

    final result = _lastAnswerCorrect ?? false;
    _answerCompleter!.complete(result);
  }

  (String pronoun, String verbForm) _splitUserAnswer(
    String raw,
    bool needsPronoun,
  ) {
    final trimmed = raw.trim();
    if (trimmed.isEmpty) return ('', '');

    if (!needsPronoun) {
      return ('', trimmed);
    }

    final lower = trimmed.toLowerCase();

    if (lower.startsWith("j'") && !lower.contains(' ')) {
      final idx = trimmed.indexOf("'");
      final pronoun = trimmed.substring(0, idx + 1);
      final verb = trimmed.substring(idx + 1).trim();
      return (pronoun, verb);
    }

    final parts = trimmed.split(RegExp(r'\s+'));
    if (parts.length >= 2) {
      final pronoun = parts.first;
      final verb = parts.sublist(1).join(' ').trim();
      return (pronoun, verb);
    }

    return ('', trimmed);
  }

  Future<void> _triggerShake() async {
    _shakeController.forward(from: 0);
  }

  Future<void> _onValidatePressed() async {
    if (_locked) return;
    final ex = _currentExercise;
    if (ex == null) return;

    final needsPronoun = _needsPronoun(ex);

    final rawAnswer = _controller.text.trim();
    if (rawAnswer.isEmpty) {
      setState(() {
        _feedback =
            'Écris la forme conjuguée complète, avec le pronom qui l’accompagne.';
      });
      await _triggerShake();
      return;
    }

    final (userPronounRaw, userVerbRaw) = _splitUserAnswer(
      rawAnswer,
      needsPronoun,
    );

    if (needsPronoun && userPronounRaw.isEmpty) {
      setState(() {
        _feedback = 'Pense à écrire le pronom et la forme conjuguée';
      });
      await _triggerShake();
      return;
    }

    final expectedForm = ex.correctAnswer.trim().toLowerCase();

    final expectedPronounRaw = needsPronoun
        ? (ex.pronoun.trim().isEmpty ? '(aucun pronom)' : ex.pronoun.trim())
        : '(aucun pronom)';

    final normExpected = _normalizePronoun(expectedPronounRaw);
    final normUser = needsPronoun
        ? _normalizePronoun(userPronounRaw)
        : '(aucun pronom)';

    bool pronounOk = true;
    if (needsPronoun) {
      pronounOk = normExpected == normUser;
    }

    // À l’impératif, on ne corrige pas le pronom
    if (ex.tense == vm.Tense.imperatif) {
      pronounOk = true;
    }

    final verbOk = userVerbRaw.trim().toLowerCase() == expectedForm;

    final isCorrect = pronounOk && verbOk;

    // On ENREGISTRE juste si c'est correct ou non mais on n'affiche PAS si c'est bon ou mauvais.
    setState(() {
      _locked = true;
      _lastAnswerCorrect = isCorrect;
    });

    await Future.delayed(const Duration(milliseconds: 150));
  }

  Future<bool> _confirmQuit() async {
    final shouldQuit =
        await showDialog<bool>(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('Quitter le test ?'),
            content: const Text(
              'Tu es sur le point de quitter le test de niveau.\n'
              'Es-tu sûr·e ?',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Continuer'),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text(
                  'Quitter',
                  style: TextStyle(color: Colors.red),
                ),
              ),
            ],
          ),
        ) ??
        false;

    if (shouldQuit) {
      Navigator.of(context).pop();
      return false;
    }

    return false;
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return WillPopScope(
      onWillPop: _confirmQuit,
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          backgroundColor: brandBlue,
          foregroundColor: Colors.white,
          title: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Test de niveau',
                style: TextStyle(fontWeight: FontWeight.w700),
              ),
              if (!_isFinished && _totalQuestions > 0) ...[
                const SizedBox(height: 2),
                Text(
                  'Question $_questionsAsked / $_totalQuestions',
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ],
          ),
        ),
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xFFEFF3FF), Color(0xFFF7F8FC)],
            ),
          ),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 720),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 22, 16, 22),
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (!_isFinished && _totalQuestions > 0) ...[
                          // Barre de progression animée
                          ClipRRect(
                            borderRadius: BorderRadius.circular(999),
                            child: LinearProgressIndicator(
                              value: _progress.clamp(0.0, 1.0),
                              minHeight: 8,
                              backgroundColor: Colors.grey.withOpacity(0.2),
                            ),
                          ),
                          const SizedBox(height: 16),
                        ],
                        AnimatedSwitcher(
                          duration: const Duration(milliseconds: 260),
                          transitionBuilder: (child, animation) {
                            final slideAnimation = Tween<Offset>(
                              begin: const Offset(0.05, 0),
                              end: Offset.zero,
                            ).animate(animation);

                            return FadeTransition(
                              opacity: animation,
                              child: SlideTransition(
                                position: slideAnimation,
                                child: child,
                              ),
                            );
                          },
                          child: _isFinished
                              ? _buildResultContent()
                              : _buildQuestionContent(),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildResultContent() {
    final level = _recommendedLevel;

    return Column(
      key: const ValueKey('result'),
      mainAxisSize: MainAxisSize.min,
      children: [
        const Text(
          'Résultat du test',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 16),
        if (level != null) ...[
          Text(
            'Niveau recommandé :',
            style: TextStyle(fontSize: 16, color: Colors.grey[800]),
          ),
          const SizedBox(height: 8),
          Chip(
            label: Text(
              _levelLabel(level),
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
            backgroundColor: brandYellow.withOpacity(.15),
          ),
        ],
        const SizedBox(height: 24),
        const Text(
          'Tu peux maintenant commencer une partie dans ce niveau. '
          'Tu pourras toujours changer de niveau plus tard depuis l\'écran d\'accueil.',
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 24),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: () async {
              if (level != null) {
                final sp = await SharedPreferences.getInstance();
                final userId = sp.getInt('current_user_id');

                if (userId != null) {
                  await AppDb.instance.setUserLevelTestResult(
                    userId: userId,
                    levelString: level.name,
                  );
                }
              }

              // On retourne à l’accueil avec le niveau recommandé
              Navigator.pop(context, level);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: brandBlue,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 14),
            ),
            child: const Text('Retour à l’accueil'),
          ),
        ),
      ],
    );
  }

  Widget _buildQuestionContent() {
    final ex = _currentExercise;
    if (ex == null) {
      return const SizedBox(
        key: ValueKey('loading-question'),
        height: 120,
        child: Center(child: CircularProgressIndicator()),
      );
    }

    final bool needsPronoun = _needsPronoun(ex);

    final personDesc = _personLabel(
      ex.pronoun.trim().isEmpty ? '(aucun pronom)' : ex.pronoun.trim(),
    );

    String headerText;
    if (ex.tense == vm.Tense.imperatif) {
      headerText = 'Temps demandé : ${ex.tenseLabel} – $personDesc';
    } else if (!needsPronoun) {
      headerText = 'Temps demandé : ${ex.tenseLabel} (forme sans pronom)';
    } else {
      headerText = 'Temps demandé : ${ex.tenseLabel} – $personDesc';
    }

    return Column(
      key: ValueKey('q-${ex.verb}-${ex.tense}-${_questionsAsked}'),
      mainAxisSize: MainAxisSize.min,
      children: [
        const SizedBox(height: 8),
        Text(
          'Conjugue le verbe suivant :',
          style: Theme.of(context).textTheme.titleMedium,
        ),
        const SizedBox(height: 8),
        Text(
          ex.verb,
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 6),
        Text(
          headerText,
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w500,
            color: Colors.black87,
          ),
        ),
        const SizedBox(height: 12),
        const Text(
          'Écris la forme conjuguée complète, avec le pronom qui l’accompagne ',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 13),
        ),
        const SizedBox(height: 18),

        AbsorbPointer(
          absorbing: _locked,
          child: AnimatedBuilder(
            animation: _shakeController,
            builder: (context, child) {
              final offsetX =
                  math.sin(_shakeController.value * math.pi * 4) * 8;
              return Transform.translate(
                offset: Offset(offsetX, 0),
                child: child,
              );
            },
            child: Opacity(
              opacity: _locked ? 0.7 : 1,
              child: TextField(
                controller: _controller,
                autofocus: true,
                textInputAction: TextInputAction.done,
                onSubmitted: (_) => _onValidatePressed(),
                decoration: InputDecoration(
                  hintText: needsPronoun
                      ? 'Ex.: je mange, tu finiras, j’irai…'
                      : 'Écris la forme conjuguée',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 14,
                  ),
                ),
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 18),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: _locked ? null : _onValidatePressed,
            icon: const Icon(Icons.check),
            label: const Text('Valider'),
            style: ElevatedButton.styleFrom(
              backgroundColor: brandBlue,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 14),
            ),
          ),
        ),

        if (_locked) ...[
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: _onNextQuestionPressed,
              icon: const Icon(Icons.arrow_forward),
              label: const Text('Suivant'),
            ),
          ),
        ],

        if (_feedback.isNotEmpty) ...[
          const SizedBox(height: 16),
          AnimatedOpacity(
            duration: const Duration(milliseconds: 200),
            opacity: 1,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.red.withOpacity(.06),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.red, width: 1),
              ),
              child: Text(
                _feedback,
                textAlign: TextAlign.center,
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
            ),
          ),
        ],

        const SizedBox(height: 16),

        Align(
          alignment: Alignment.center,
          child: TextButton.icon(
            onPressed: _confirmQuit,
            icon: const Icon(Icons.exit_to_app),
            label: const Text('Quitter le test'),
            style: TextButton.styleFrom(foregroundColor: Colors.red[700]),
          ),
        ),
      ],
    );
  }

  vm.GameLevel _findCurrentLevelForExercise(vm.Exercise ex) {
    for (final cfg in _placementConfigs) {
      final verbs = kLevelVerbs[cfg.level] ?? const <String>[];
      if (verbs.contains(ex.verb)) {
        return cfg.level;
      }
    }
    return vm.GameLevel.level_cycle1;
  }
}
