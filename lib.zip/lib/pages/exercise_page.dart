import 'package:conjufun/data/app_db.dart';
import 'package:flutter/material.dart';
import '../main.dart' show brandBlue;
import '../viewmodels/exercise_vm.dart' as vm;
import 'home_page.dart' show SessionMode;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:confetti/confetti.dart';
import '../models/custom_set.dart';

class ShakeAnimation extends StatelessWidget {
  final Animation<double> animation;
  final Widget child;

  const ShakeAnimation({
    super.key,
    required this.animation,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    final double offset = 10 * (animation.value - 0.5);
    return Transform.translate(offset: Offset(offset, 0), child: child);
  }
}

class PopAnimation extends StatelessWidget {
  final Animation<double> animation;
  final Widget child;

  const PopAnimation({super.key, required this.animation, required this.child});

  @override
  Widget build(BuildContext context) {
    final double scale = 1 + (0.15 * animation.value);
    return Transform.scale(scale: scale, child: child);
  }
}

class FlashBackground extends StatelessWidget {
  final Animation<double> animation;
  final bool isCorrect;
  final Widget child;

  const FlashBackground({
    super.key,
    required this.animation,
    required this.isCorrect,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    final color = isCorrect ? Colors.green : Colors.red;

    return Stack(
      alignment: Alignment.center,
      children: [
        Opacity(
          opacity: animation.value * 0.25,
          child: Container(
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        ),
        child,
      ],
    );
  }
}

class ExercisePage extends StatefulWidget {
  const ExercisePage({
    super.key,
    this.mode = SessionMode.unlimited,
    this.fixedCount,
    required this.level,
    this.customSet,
  });

  final SessionMode mode;
  final int? fixedCount;
  final vm.GameLevel level;
  final CustomSet? customSet;

  @override
  State<ExercisePage> createState() => _ExercisePageState();
}

enum _AnswerFeedback { none, correct, wrong }

class _ExercisePageState extends State<ExercisePage> {
  final vm.ExerciseViewModel _viewModel = vm.ExerciseViewModel();
  final TextEditingController _controller = TextEditingController();
  final TextEditingController _pronounController = TextEditingController();

  final AudioPlayer _badgePlayer = AudioPlayer();
  final AudioPlayer _fxPlayer = AudioPlayer();
  late ConfettiController _confettiController;

  String _feedback = '';
  bool _locked = false;
  String _explanation = '';
  vm.Exercise? _exerciseForDetails;
  _AnswerFeedback _answerState = _AnswerFeedback.none;
  bool _emptyShake = false;

  bool _streakUpdatedForThisSession = false;

  bool _needsPronoun(vm.Exercise ex) {
    switch (ex.tense) {
      case vm.Tense.imperatif:
        return false;
      case vm.Tense.infinitif:
      case vm.Tense.infinitifPasse:
      case vm.Tense.gerondif:
      case vm.Tense.participePresent:
      case vm.Tense.participePasse:
        return false;
      default:
        return true;
    }
  }

  @override
  void initState() {
    super.initState();
    _confettiController = ConfettiController(
      duration: const Duration(seconds: 2),
    );
    _init();
  }

  Future<void> _init() async {
    await _viewModel.init();

    final sp = await SharedPreferences.getInstance();
    final userId = sp.getInt('current_user_id');
    _viewModel.setCurrentUserId(userId);

    await _viewModel.configureSession(
      mode: widget.mode == SessionMode.unlimited
          ? vm.VmSessionMode.unlimited
          : vm.VmSessionMode.fixed,
      fixedCount: widget.mode == SessionMode.fixed
          ? (widget.fixedCount ?? 10)
          : 0,
      level: widget.level,
      customSet: widget.customSet,
    );

    await _viewModel.nextExercise();

    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _controller.dispose();
    _pronounController.dispose();
    _badgePlayer.dispose();
    _fxPlayer.dispose();
    _confettiController.dispose();
    super.dispose();
  }

  Future<void> _playCorrectFx() async {
    try {
      await _fxPlayer.play(AssetSource('sounds/correct.mp3'));
    } catch (_) {}
  }

  Future<void> _playWrongFx() async {
    try {
      await _fxPlayer.play(AssetSource('sounds/wrong.mp3'));
    } catch (_) {}
  }

  Future<void> _playBadgeSound() async {
    try {
      await _badgePlayer.play(AssetSource('sounds/badge.mp3'));
    } catch (_) {}
  }

  Future<void> _updateStreakAtEnd() async {
    if (_streakUpdatedForThisSession) return;

    final uid = _viewModel.userId;
    if (uid == null) return;

    _streakUpdatedForThisSession = true;

    final s = await AppDb.instance.updateStreakAfterSession(
      userId: uid,
      sessionTime: DateTime.now(),
    );

    if (!mounted) return;
    setState(() {
      _viewModel.currentStreak = s['current'] ?? 0;
      _viewModel.bestStreak = s['best'] ?? 0;
    });
  }

  Future<bool> _confirmQuit() async {
    final shouldQuit =
        await showDialog<bool>(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('Quitter la partie ?'),
            content: const Text(
              'Tu es sur le point de quitter la partie.\n'
              'Ton score en cours pourrait ne pas être enregistré.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Continuer'),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text(
                  'Quitter',
                  style: TextStyle(color: Colors.red),
                ),
              ),
            ],
          ),
        ) ??
        false;
    return shouldQuit;
  }

  Future<void> _onQuitPressed() async {
    final ok = await _confirmQuit();
    if (!ok || !mounted) return;

    await _updateStreakAtEnd();
    if (!mounted) return;

    Navigator.pop(context, true);
  }

  Future<void> _showBadgeDialog(List<String> badges) async {
    if (!mounted || badges.isEmpty) return;

    await _playBadgeSound();
    if (!mounted) return;

    await showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'badge',
      transitionDuration: const Duration(milliseconds: 300),
      pageBuilder: (_, __, ___) {
        return Center(
          child: Material(
            color: Colors.transparent,
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 24),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.15),
                    blurRadius: 20,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: const [
                      CircleAvatar(
                        radius: 22,
                        backgroundColor: Colors.amber,
                        child: Icon(
                          Icons.emoji_events,
                          color: Colors.white,
                          size: 26,
                        ),
                      ),
                      SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          'Nouveau badge débloqué !',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  ...badges.map(
                    (b) => Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Text(
                        '• $b',
                        style: const TextStyle(
                          fontWeight: FontWeight.w600,
                          color: brandBlue,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('OK'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
      transitionBuilder: (_, anim, __, child) {
        return Transform.scale(
          scale: Curves.easeOutBack.transform(anim.value),
          child: Opacity(opacity: anim.value, child: child),
        );
      },
    );
  }

  Future<void> _showFixedSummary() async {
    final newRecord = await _viewModel.finalizeAndMaybeRecord();
    await _updateStreakAtEnd();

    final finalScore = _viewModel.score;
    final record = _viewModel.highScore;
    final badgeInfo = await _viewModel.computeGlobalBadge();
    final newBadges = await _viewModel.checkForNewBadges();

    if (newRecord || _viewModel.successPercent == 100) {
      _confettiController.play();
    }

    if (!mounted) return;
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(newRecord ? 'Nouveau record' : 'Fin de la session'),
        content: Text(
          'Résultats:\n'
          '- Score: $finalScore\n'
          '- Record: $record\n'
          '${badgeInfo == null ? '' : '\nBadge: ${vm.badgeLabel(badgeInfo.rank)}'
                    '${badgeInfo.rank == vm.BadgeRank.diamond ? '\nRang maximum atteint.' : '\nProchain badge: ${badgeInfo.nextThreshold} pts.'}'}',
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _viewModel.startNewRound();
              setState(() {
                _locked = false;
                _answerState = _AnswerFeedback.none;
                _feedback = '';
                _explanation = '';
                _controller.clear();
                _pronounController.clear();
              });
            },
            child: const Text('Recommencer'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context, true);
            },
            child: const Text('Accueil'),
          ),
        ],
      ),
    );

    if (newBadges.isNotEmpty) {
      await _showBadgeDialog(newBadges);
    }

    _viewModel.resetScore();
    await _viewModel.startNewRound();

    if (mounted) {
      setState(() {
        _locked = false;
        _answerState = _AnswerFeedback.none;
        _feedback = '';
        _explanation = '';
        _controller.clear();
        _pronounController.clear();
      });
    }
  }

  Future<void> _onCorrect() async {
    final ex = _viewModel.currentExercise;
    if (ex != null && _viewModel.userId != null) {
      await AppDb.instance.incrementStat(
        ex.tenseLabel,
        correct: true,
        userId: _viewModel.userId!,
      );
    }

    _viewModel.addPointsForCurrent();
    final pts = _viewModel.pointsForCurrent();

    setState(() {
      _locked = true;
      _answerState = _AnswerFeedback.correct;
      _feedback = 'Bonne réponse (+$pts pts)';
      _explanation = '';
    });

    await _playCorrectFx();
  }

  Future<void> _onWrong({
    required String expected,
    String? explanation,
    String? errorHint,
  }) async {
    final ex = _viewModel.currentExercise;

    if (ex != null && _viewModel.userId != null) {
      try {
        await AppDb.instance.incrementStat(
          ex.tenseLabel,
          correct: false,
          userId: _viewModel.userId!,
        );
      } catch (_) {}
    }

    _exerciseForDetails = ex;

    if (_viewModel.mode == vm.VmSessionMode.fixed) {
      if (!mounted) return;

      setState(() {
        _locked = true;
        _answerState = _AnswerFeedback.wrong;

        final buffer = StringBuffer();
        buffer.writeln('Mauvaise réponse.');
        buffer.writeln('Réponse attendue : $expected');

        if (errorHint != null && errorHint.isNotEmpty) {
          buffer.writeln();
          buffer.writeln(errorHint);
        }

        _feedback = buffer.toString();
        _explanation = (explanation ?? '').trim();
      });

      await _playWrongFx();
      return;
    }

    await _playWrongFx();

    final newRecord = await _viewModel.onWrongAnswerAndMaybeUpdateRecord();
    await _updateStreakAtEnd();

    final finalScore = _viewModel.score;
    final record = _viewModel.highScore;
    final newBadges = await _viewModel.checkForNewBadges();

    if (newRecord) {
      _confettiController.play();
    }

    if (!mounted) return;

    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(newRecord ? 'Nouveau record' : 'Fin de la partie'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Score : $finalScore\nRecord : $record'),
            const SizedBox(height: 12),
            Text('Réponse attendue : $expected'),
            if (errorHint != null && errorHint.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(errorHint, style: const TextStyle(fontSize: 14)),
            ],
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              final e = _exerciseForDetails ?? _viewModel.currentExercise;
              if (e != null) _showFullConjugation(e);
            },
            child: const Text('Conjugaison complète'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Recommencer'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context, true);
            },
            child: const Text('Accueil'),
          ),
        ],
      ),
    );

    if (newBadges.isNotEmpty) {
      await _showBadgeDialog(newBadges);
    }

    _viewModel.resetScore();
    await _viewModel.startNewRound();

    if (mounted) {
      setState(() {
        _feedback = '';
        _explanation = '';
        _controller.clear();
        _pronounController.clear();
        _locked = false;
        _answerState = _AnswerFeedback.none;
      });
    }
  }

  String _buildErrorHint({
    required bool pronounOk,
    required bool verbOk,
    required String expectedPronoun,
  }) {
    if (pronounOk && !verbOk) {
      return 'Le pronom est bon, mais la forme conjuguée est incorrecte.';
    } else if (!pronounOk && verbOk) {
      if (expectedPronoun == '(aucun pronom)') {
        return 'La forme est bonne, mais aucun pronom n’était attendu.';
      }
      return 'La forme est bonne, mais le pronom attendu était « $expectedPronoun ».';
    } else if (!pronounOk && !verbOk) {
      if (expectedPronoun == '(aucun pronom)') {
        return 'Le pronom et la forme sont incorrects. Aucun pronom n’était attendu.';
      }
      return 'Le pronom et la forme sont incorrects. Pronom attendu : « $expectedPronoun ».';
    }
    return '';
  }

  String _personLabel(String pronoun) {
    final p = pronoun.trim().toLowerCase();

    switch (p) {
      case 'je':
      case "j'":
        return '1re personne du singulier';
      case 'tu':
        return '2e personne du singulier';
      case 'il':
        return '3e personne du singulier (masculin)';
      case 'elle':
        return '3e personne du singulier (féminin)';
      case 'nous':
        return '1re personne du pluriel';
      case 'vous':
        return '2e personne du pluriel';
      case 'ils':
        return '3e personne du pluriel (masculin)';
      case 'elles':
        return '3e personne du pluriel (féminin)';
      case '(aucun pronom)':
        return 'forme sans pronom';
      default:
        return 'personne non spécifiée';
    }
  }

  String _normalizePronoun(String p) {
    final v = p.trim().toLowerCase();
    final normalized = v.replaceAll('’', "'");
    if (normalized.isEmpty) return '(aucun pronom)';
    return normalized;
  }

  Future<void> _checkAnswer() async {
    if (_locked) return;
    final ex = _viewModel.currentExercise;
    if (ex == null) return;

    final bool needsPronoun = _needsPronoun(ex);

    final raw = _controller.text.trim();
    if (raw.isEmpty) {
      setState(() {
        _emptyShake = true;
        _answerState = _AnswerFeedback.none;
        _feedback = 'Écris une réponse avant de valider.';
        _explanation = '';
      });

      await Future.delayed(const Duration(milliseconds: 250));

      if (mounted) {
        setState(() => _emptyShake = false);
      }
      return;
    }

    if (ex.tense == vm.Tense.imperatif) {
      final parts = raw
          .split(RegExp(r'\s+'))
          .where((p) => p.isNotEmpty)
          .toList();
      final first = parts.first.toLowerCase();

      const pronouns = [
        'je',
        "j'",
        'tu',
        'il',
        'elle',
        'nous',
        'vous',
        'ils',
        'elles',
      ];

      if (pronouns.contains(first) && parts.length >= 2) {
        setState(() {
          _answerState = _AnswerFeedback.none;
          _feedback =
              'À l’impératif, pas de pronom. Écris seulement la forme verbale.';
          _explanation = '';
        });
        return;
      }

      final verbOk = _viewModel.isAnswerCorrect(raw.toLowerCase());
      final expectedForm = ex.correctAnswer.trim();
      final expectedDisplay = expectedForm;

      final explanation = _viewModel.getExplanationForCurrent();
      _exerciseForDetails = ex;

      if (verbOk) {
        setState(() {
          _feedback = 'Bonne réponse.';
          _explanation = '';
        });
        await _onCorrect();
        return;
      }

      setState(() {
        _feedback = '';
        _explanation = '';
      });

      await _onWrong(
        expected: expectedDisplay,
        explanation: explanation,
        errorHint: 'Forme attendue : « $expectedForm » (sans pronom).',
      );
      return;
    }

    String userPronoun = '';
    String userVerb = raw;

    if (needsPronoun) {
      final parts = raw
          .split(RegExp(r'\s+'))
          .where((p) => p.isNotEmpty)
          .toList();
      userPronoun = parts.first;
      userVerb = parts.sublist(1).join(' ');
    }

    final expectedForm = ex.correctAnswer.trim();

    String expectedPronounRaw = '';
    if (needsPronoun) {
      expectedPronounRaw = ex.pronoun.trim().isEmpty
          ? '(aucun pronom)'
          : ex.pronoun.trim();
    }

    bool pronounOk = true;
    String expectedPronounDisplay = '';

    if (needsPronoun) {
      final normExpected = _normalizePronoun(expectedPronounRaw);
      final normUser = _normalizePronoun(userPronoun);
      pronounOk = normExpected == normUser;
      expectedPronounDisplay = expectedPronounRaw;
    }

    final verbOk = _viewModel.isAnswerCorrect(userVerb.toLowerCase());

    final expectedDisplay =
        needsPronoun &&
            expectedPronounRaw.isNotEmpty &&
            expectedPronounRaw != '(aucun pronom)'
        ? '${ex.pronoun.trim()} $expectedForm'
        : expectedForm;

    final explanation = _viewModel.getExplanationForCurrent();
    _exerciseForDetails = ex;

    final errorHint = _buildErrorHint(
      pronounOk: pronounOk,
      verbOk: verbOk,
      expectedPronoun: needsPronoun
          ? (expectedPronounDisplay.isEmpty
                ? '(aucun pronom)'
                : expectedPronounDisplay)
          : '(aucun pronom)',
    );

    if (pronounOk && verbOk) {
      setState(() {
        _feedback = 'Bonne réponse.';
        _explanation = '';
      });
      await _onCorrect();
      return;
    }

    setState(() {
      _feedback = '';
      _explanation = '';
    });

    await _onWrong(
      expected: expectedDisplay,
      explanation: explanation,
      errorHint: errorHint,
    );
  }

  void _showFullConjugation(vm.Exercise ex) {
    final full = _viewModel.getFullConjugationForExercise(ex);

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Conjugaison de "${ex.verb}" (${ex.tenseLabel})'),
          content: full.isEmpty
              ? const Text(
                  'Conjugaison complète non disponible pour ce verbe/temps.',
                )
              : Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: full.entries
                      .map((e) => Text('${e.key} → ${e.value}'))
                      .toList(),
                ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Fermer'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final ex = _viewModel.currentExercise;
    if (ex == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final bool needsPronoun = _needsPronoun(ex);

    final personDesc = _personLabel(
      ex.pronoun.trim().isEmpty ? '(aucun pronom)' : ex.pronoun.trim(),
    );

    String headerText;
    if (ex.tense == vm.Tense.imperatif) {
      headerText = 'Temps demandé : ${ex.tenseLabel} – $personDesc';
    } else if (!needsPronoun) {
      headerText = 'Temps demandé : ${ex.tenseLabel}';
    } else {
      headerText = 'Temps demandé : ${ex.tenseLabel} – $personDesc';
    }

    final showProgress =
        _viewModel.mode == vm.VmSessionMode.fixed && _viewModel.targetCount > 0;
    final isFixed = _viewModel.mode == vm.VmSessionMode.fixed;

    return WillPopScope(
      onWillPop: _confirmQuit,
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          backgroundColor: brandBlue,
          foregroundColor: Colors.white,
          title: FittedBox(
            fit: BoxFit.scaleDown,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (isFixed) ...[
                  Text(
                    'Réussite: ${_viewModel.successPercent}%',
                    style: const TextStyle(
                      fontWeight: FontWeight.w800,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(width: 16),
                  if (showProgress) ...[
                    Text(
                      _viewModel.progressLabel,
                      style: const TextStyle(
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(width: 16),
                  ],
                ],
                Text(
                  'Score: ${_viewModel.score}',
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
          ),
        ),
        body: Stack(
          children: [
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFFEFF3FF), Color(0xFFF7F8FC)],
                ),
              ),
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 720),
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(16, 22, 16, 22),
                    child: Card(
                      child: Padding(
                        padding: const EdgeInsets.all(20),
                        child: SingleChildScrollView(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Chip(
                                    label: Text(
                                      _viewModel.level ==
                                              vm.GameLevel.level_cycle1
                                          ? 'Niveau 1'
                                          : _viewModel.level ==
                                                vm.GameLevel.level_cycle2
                                          ? 'Niveau 2'
                                          : _viewModel.level ==
                                                vm.GameLevel.level_cycle3
                                          ? 'Niveau 3'
                                          : _viewModel.level ==
                                                vm.GameLevel.level_sec1
                                          ? 'Niveau 4'
                                          : _viewModel.level ==
                                                vm.GameLevel.level_sec2
                                          ? 'Niveau 5'
                                          : 'Expert',
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'Écris le pronom et conjugue le verbe suivant :',
                                style: Theme.of(context).textTheme.titleMedium,
                              ),
                              const SizedBox(height: 8),
                              Text(
                                ex.verb,
                                style: const TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                headerText,
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500,
                                  color: Colors.black87,
                                ),
                              ),
                              const SizedBox(height: 16),
                              const SizedBox(height: 12),
                              AbsorbPointer(
                                absorbing: _locked,
                                child: Opacity(
                                  opacity: _locked ? 0.7 : 1,
                                  child: AnimatedSwitcher(
                                    duration: const Duration(milliseconds: 200),
                                    transitionBuilder: (child, animation) {
                                      if (_emptyShake) {
                                        return ShakeAnimation(
                                          animation: animation,
                                          child: child,
                                        );
                                      }
                                      return FadeTransition(
                                        opacity: animation,
                                        child: child,
                                      );
                                    },
                                    child: TextField(
                                      key: ValueKey<bool>(_emptyShake),
                                      controller: _controller,
                                      autofocus: true,
                                      textInputAction: TextInputAction.done,
                                      onSubmitted: (_) => _checkAnswer(),
                                      decoration: InputDecoration(
                                        hintText:
                                            'Exemple : il fait, je mange, tu es allé…',
                                        border: OutlineInputBorder(
                                          borderRadius: BorderRadius.circular(
                                            14,
                                          ),
                                        ),
                                        contentPadding:
                                            const EdgeInsets.symmetric(
                                              horizontal: 14,
                                              vertical: 14,
                                            ),
                                      ),
                                      style: const TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 18),
                              SizedBox(
                                width: double.infinity,
                                child: ElevatedButton.icon(
                                  onPressed: _locked
                                      ? null
                                      : () => _checkAnswer(),
                                  icon: const Icon(Icons.check),
                                  label: const Text('Valider'),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: brandBlue,
                                    foregroundColor: Colors.white,
                                    padding: const EdgeInsets.symmetric(
                                      vertical: 14,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 16),
                              AnimatedSwitcher(
                                duration: const Duration(milliseconds: 260),
                                transitionBuilder: (child, animation) {
                                  final curved = CurvedAnimation(
                                    parent: animation,
                                    curve: Curves.easeOut,
                                  );

                                  if (_answerState == _AnswerFeedback.correct) {
                                    return FlashBackground(
                                      animation: curved,
                                      isCorrect: true,
                                      child: PopAnimation(
                                        animation: curved,
                                        child: child,
                                      ),
                                    );
                                  } else if (_answerState ==
                                      _AnswerFeedback.wrong) {
                                    return FlashBackground(
                                      animation: curved,
                                      isCorrect: false,
                                      child: ShakeAnimation(
                                        animation: curved,
                                        child: child,
                                      ),
                                    );
                                  } else {
                                    return FadeTransition(
                                      opacity: curved,
                                      child: ScaleTransition(
                                        scale: Tween<double>(
                                          begin: 0.95,
                                          end: 1,
                                        ).animate(curved),
                                        child: child,
                                      ),
                                    );
                                  }
                                },
                                child: _feedback.isEmpty
                                    ? const SizedBox.shrink()
                                    : Container(
                                        key: ValueKey<String>(
                                          _feedback + _answerState.toString(),
                                        ),
                                        padding: const EdgeInsets.all(12),
                                        decoration: BoxDecoration(
                                          color:
                                              _answerState ==
                                                  _AnswerFeedback.correct
                                              ? Colors.green.withOpacity(.10)
                                              : _answerState ==
                                                    _AnswerFeedback.wrong
                                              ? Colors.red.withOpacity(.10)
                                              : Colors.blueGrey.withOpacity(
                                                  .08,
                                                ),
                                          borderRadius: BorderRadius.circular(
                                            12,
                                          ),
                                          border: Border.all(
                                            color:
                                                _answerState ==
                                                    _AnswerFeedback.correct
                                                ? Colors.green
                                                : _answerState ==
                                                      _AnswerFeedback.wrong
                                                ? Colors.red
                                                : Colors.blueGrey,
                                            width: 1,
                                          ),
                                        ),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.min,
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Icon(
                                              _answerState ==
                                                      _AnswerFeedback.correct
                                                  ? Icons.check_circle
                                                  : _answerState ==
                                                        _AnswerFeedback.wrong
                                                  ? Icons.cancel
                                                  : Icons.info_outline,
                                            ),
                                            const SizedBox(width: 8),
                                            Flexible(
                                              child: Text(
                                                _feedback,
                                                textAlign: TextAlign.center,
                                                style: const TextStyle(
                                                  fontWeight: FontWeight.w700,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                              ),
                              if (_locked &&
                                  _viewModel.mode == vm.VmSessionMode.fixed &&
                                  _feedback.isNotEmpty) ...[
                                const SizedBox(height: 8),
                                TextButton(
                                  onPressed: () {
                                    final cur = _viewModel.currentExercise;
                                    if (cur != null) {
                                      _showFullConjugation(cur);
                                    }
                                  },
                                  child: const Text(
                                    'Voir la conjugaison complète',
                                    style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      color: brandBlue,
                                    ),
                                  ),
                                ),
                              ],
                              if (_explanation.isNotEmpty &&
                                  _viewModel.mode ==
                                      vm.VmSessionMode.unlimited) ...[
                                const SizedBox(height: 8),
                                Text(
                                  _explanation,
                                  textAlign: TextAlign.left,
                                  style: const TextStyle(fontSize: 14),
                                ),
                                const SizedBox(height: 4),
                                TextButton(
                                  onPressed: () {
                                    final cur = _viewModel.currentExercise;
                                    if (cur != null) {
                                      _showFullConjugation(cur);
                                    }
                                  },
                                  child: const Text(
                                    'Voir la conjugaison complète',
                                  ),
                                ),
                              ],
                              if (_locked &&
                                  _viewModel.mode ==
                                      vm.VmSessionMode.fixed) ...[
                                const SizedBox(height: 12),
                                Align(
                                  alignment: Alignment.centerRight,
                                  child: ElevatedButton.icon(
                                    onPressed: () async {
                                      _viewModel.incrementAskedIfFixed();
                                      if (_viewModel.mode ==
                                              vm.VmSessionMode.fixed &&
                                          _viewModel.askedCount >=
                                              _viewModel.targetCount) {
                                        if (!mounted) return;
                                        setState(() => _locked = false);
                                        await _showFixedSummary();
                                        return;
                                      }
                                      await _viewModel.nextExercise();
                                      if (!mounted) return;

                                      setState(() {
                                        _locked = false;
                                        _answerState = _AnswerFeedback.none;
                                        _feedback = '';
                                        _explanation = '';
                                        _controller.clear();
                                        _pronounController.clear();
                                      });
                                    },
                                    icon: const Icon(Icons.arrow_forward),
                                    label: const Text('Suivant'),
                                  ),
                                ),
                              ],
                              if (_locked &&
                                  _viewModel.mode ==
                                      vm.VmSessionMode.unlimited) ...[
                                const SizedBox(height: 12),
                                Align(
                                  alignment: Alignment.centerRight,
                                  child: ElevatedButton.icon(
                                    onPressed: () async {
                                      await _viewModel.nextExercise();
                                      if (!mounted) return;

                                      setState(() {
                                        _locked = false;
                                        _answerState = _AnswerFeedback.none;
                                        _feedback = '';
                                        _explanation = '';
                                        _controller.clear();
                                        _pronounController.clear();
                                      });
                                    },
                                    icon: const Icon(Icons.arrow_forward),
                                    label: const Text('Suivant'),
                                  ),
                                ),
                              ],
                              const SizedBox(height: 16),
                              Align(
                                alignment: Alignment.center,
                                child: TextButton.icon(
                                  onPressed: _onQuitPressed,
                                  icon: const Icon(Icons.exit_to_app),
                                  label: const Text('Quitter la partie'),
                                  style: TextButton.styleFrom(
                                    foregroundColor: Colors.red,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Align(
              alignment: Alignment.topCenter,
              child: ConfettiWidget(
                confettiController: _confettiController,
                blastDirectionality: BlastDirectionality.explosive,
                shouldLoop: false,
                emissionFrequency: 0.05,
                numberOfParticles: 25,
                maxBlastForce: 30,
                minBlastForce: 10,
                gravity: 0.4,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
