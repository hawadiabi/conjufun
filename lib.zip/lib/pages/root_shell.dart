import 'package:flutter/material.dart';
import '../main.dart' show brandBlue, brandYellow;
import 'home_page.dart';
import 'verb_list_page.dart';
import 'history_page.dart';
import 'dashboard_page.dart';
import 'settings_page.dart';
import '../data/sync_service.dart';

class RootShell extends StatefulWidget {
  const RootShell({super.key});

  @override
  State<RootShell> createState() => _RootShellState();
}

class _RootShellState extends State<RootShell> {
  int _index = 0;

  final _pages = const [
    HomePage(),
    HistoryPage(),
    VerbListPage(),
    DashboardPage(),
    SettingsPage(),
  ];

  @override
  void initState() {
    super.initState();
    _triggerInitialSync();
  }

  Future<void> _triggerInitialSync() async {
    await SyncService.instance.syncCustomSetsIfEnabled();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _index, children: _pages),
      bottomNavigationBar: NavigationBarTheme(
        data: NavigationBarThemeData(
          indicatorColor: brandYellow.withOpacity(.25),
          backgroundColor: Colors.white,
          surfaceTintColor: Colors.transparent,
          labelTextStyle: WidgetStateProperty.resolveWith<TextStyle>(
            (states) => TextStyle(
              fontWeight: FontWeight.w700,
              color: states.contains(WidgetState.selected)
                  ? brandYellow
                  : brandBlue,
            ),
          ),
          iconTheme: WidgetStateProperty.resolveWith<IconThemeData>(
            (states) => IconThemeData(
              color: states.contains(WidgetState.selected)
                  ? brandYellow
                  : brandBlue,
            ),
          ),
        ),
        child: NavigationBar(
          selectedIndex: _index,
          onDestinationSelected: (i) => setState(() => _index = i),
          destinations: const [
            NavigationDestination(
              icon: Icon(Icons.home_outlined),
              selectedIcon: Icon(Icons.home),
              label: 'Accueil',
            ),
            NavigationDestination(
              icon: Icon(Icons.history_outlined),
              selectedIcon: Icon(Icons.history),
              label: 'Historique',
            ),
            NavigationDestination(
              icon: Icon(Icons.menu_book_outlined),
              selectedIcon: Icon(Icons.menu_book),
              label: 'Verbes',
            ),
            NavigationDestination(
              icon: Icon(Icons.dashboard_outlined),
              selectedIcon: Icon(Icons.dashboard),
              label: 'Tableau de bord',
            ),
            NavigationDestination(
              icon: Icon(Icons.settings_outlined),
              selectedIcon: Icon(Icons.settings),
              label: 'Paramètres', //
            ),
          ],
        ),
      ),
    );
  }
}
