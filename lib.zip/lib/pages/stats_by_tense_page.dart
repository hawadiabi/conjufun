import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:fl_chart/fl_chart.dart';

import '../data/app_db.dart';
import '../main.dart' show brandBlue, brandYellow;

class StatsByTensePage extends StatefulWidget {
  const StatsByTensePage({super.key});

  @override
  State<StatsByTensePage> createState() => _StatsByTensePageState();
}

class _StatsByTensePageState extends State<StatsByTensePage> {
  late Future<List<Map<String, dynamic>>> _futureStats;

  @override
  void initState() {
    super.initState();
    _futureStats = _loadStats();
  }

  Future<List<Map<String, dynamic>>> _loadStats() async {
    final sp = await SharedPreferences.getInstance();
    final userId = sp.getInt('current_user_id');
    // récupère les stats pour l'utilisateur (ou 0 = invité)
    return AppDb.instance.getStatsByTense(userId: userId);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Statistiques par temps'),
        backgroundColor: brandBlue,
        foregroundColor: Colors.white,
      ),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: _futureStats,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(
              child: Text('Erreur: ${snapshot.error}'),
            );
          }

          final rows = snapshot.data ?? [];
          if (rows.isEmpty) {
            return const Center(
              child: Text('Aucune statistique disponible pour le moment.'),
            );
          }

          // On calcule les % de réussite
          final stats = rows.map((r) {
            final tense = (r['tense'] as String?) ?? 'Inconnu';
            final correct = (r['correct'] as int?) ?? 0;
            final wrong = (r['wrong'] as int?) ?? 0;
            final total = correct + wrong;
            final pct = total == 0 ? 0.0 : (correct * 100.0 / total);
            return _TenseStat(
              tense: tense,
              correct: correct,
              wrong: wrong,
              percent: pct,
            );
          }).toList();

          // pour l’échelle max (ex: si tu rates beaucoup, le max reste 100)
          const maxY = 100.0;

          return Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                // ----------- GRAPHIQUE EN BARRES -----------
                Card(
                  elevation: 2,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Taux de réussite par temps',
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 16,
                          ),
                        ),
                        const SizedBox(height: 12),
                        SizedBox(
                          height: 260,
                          child: BarChart(
                            BarChartData(
                              maxY: maxY,
                              minY: 0,
                              gridData: FlGridData(
                                show: true,
                                horizontalInterval: 20,
                                getDrawingHorizontalLine: (value) =>
                                    FlLine(color: Colors.grey.withOpacity(.2)),
                              ),
                              titlesData: FlTitlesData(
                                leftTitles: AxisTitles(
                                  sideTitles: SideTitles(
                                    showTitles: true,
                                    reservedSize: 32,
                                    interval: 20,
                                    getTitlesWidget: (value, meta) {
                                      return Text(
                                        '${value.toInt()}%',
                                        style: const TextStyle(fontSize: 10),
                                      );
                                    },
                                  ),
                                ),
                                bottomTitles: AxisTitles(
                                  sideTitles: SideTitles(
                                    showTitles: true,
                                    reservedSize: 48,
                                    getTitlesWidget: (value, meta) {
                                      final index = value.toInt();
                                      if (index < 0 || index >= stats.length) {
                                        return const SizedBox.shrink();
                                      }
                                      final tense = stats[index].tense;
                                      // petit label compact (ex: "prés." / "imp.")
                                      final short = _shortLabel(tense);
                                      return Padding(
                                        padding:
                                            const EdgeInsets.only(top: 4.0),
                                        child: RotatedBox(
                                          quarterTurns: 1,
                                          child: Text(
                                            short,
                                            style:
                                                const TextStyle(fontSize: 10),
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                                topTitles: AxisTitles(
                                  sideTitles:
                                      SideTitles(showTitles: false),
                                ),
                                rightTitles: AxisTitles(
                                  sideTitles:
                                      SideTitles(showTitles: false),
                                ),
                              ),
                              borderData: FlBorderData(show: false),
                              barGroups: List.generate(stats.length, (i) {
                                final s = stats[i];
                                return BarChartGroupData(
                                  x: i,
                                  barRods: [
                                    BarChartRodData(
                                      toY: s.percent,
                                      width: 18,
                                      borderRadius: BorderRadius.circular(8),
                                      color: brandYellow,
                                    ),
                                  ],
                                );
                              }),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 16),

                // ----------- LISTE DÉTAILLÉE (texte + barre) -----------
                Expanded(
                  child: ListView.builder(
                    itemCount: stats.length,
                    itemBuilder: (context, index) {
                      final s = stats[index];
                      final total = s.correct + s.wrong;
                      final pctText = s.percent.toStringAsFixed(1);

                      return Card(
                        margin: const EdgeInsets.only(bottom: 10),
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                s.tense,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w800,
                                  fontSize: 15,
                                  color: brandBlue,
                                ),
                              ),
                              const SizedBox(height: 6),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text('Réussite : $pctText %'),
                                  Text('${s.correct} / $total correctes'),
                                ],
                              ),
                              const SizedBox(height: 6),
                              ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: LinearProgressIndicator(
                                  value: total == 0
                                      ? 0
                                      : s.percent / 100.0,
                                  minHeight: 8,
                                  backgroundColor:
                                      brandBlue.withOpacity(.1),
                                  valueColor:
                                      const AlwaysStoppedAnimation(brandYellow),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

/// petit modèle local
class _TenseStat {
  final String tense;
  final int correct;
  final int wrong;
  final double percent;

  _TenseStat({
    required this.tense,
    required this.correct,
    required this.wrong,
    required this.percent,
  });
}

/// pour avoir des labels courts sur l’axe X
String _shortLabel(String tense) {
  switch (tense.toLowerCase()) {
    case 'présent':
      return 'prés.';
    case 'imparfait':
      return 'imp.';
    case 'futur simple':
      return 'futur';
    case 'conditionnel présent':
      return 'cond.';
    case 'subjonctif présent':
      return 'subj.';
    case 'subjonctif imparfait':
      return 'subj. imp.';
    case 'passé simple':
      return 'p. simple';
    case 'passé composé':
      return 'p. comp.';
    case 'futur proche':
      return 'futur pr.';
    default:
      // si inconnu, on coupe à 6 caractères
      return tense.length > 6 ? '${tense.substring(0, 6)}…' : tense;
  }
}
