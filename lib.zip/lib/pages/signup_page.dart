import 'package:flutter/material.dart';
import '../data/app_db.dart';
import 'package:crypto/crypto.dart';
import 'dart:convert';
import 'dart:math';

import 'package:shared_preferences/shared_preferences.dart';

class SignupPage extends StatefulWidget {
  const SignupPage({super.key});

  @override
  State<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _name = TextEditingController();
  String? _message;

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    _name.dispose();
    super.dispose();
  }

  String _randomSalt(int length) {
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    final rand = Random.secure();
    return List.generate(
      length,
      (_) => chars[rand.nextInt(chars.length)],
    ).join();
  }

  Future<void> _signup() async {
    final email = _email.text.trim();
    final password = _password.text.trim();
    final name = _name.text.trim();

    if (email.isEmpty || password.isEmpty || name.isEmpty) {
      setState(() => _message = 'Tous les champs sont obligatoires.');
      return;
    }

    // 1) Vérifier si l'email existe déjà
    final existing = await AppDb.instance.getUserByEmail(email);
    if (existing != null) {
      setState(() => _message = 'Cet email est déjà utilisé.');
      return;
    }

    final salt = _randomSalt(16);
    final hash = sha256.convert(utf8.encode('$salt$password')).toString();

    try {
      final userId = await AppDb.instance.insertUser(
        email: email.toLowerCase(),
        passwordHash: hash,
        salt: salt,
        displayName: name,
      );

      // 3) Rattacher les runs d'invité à ce nouvel utilisateur
      await AppDb.instance.attachGuestRunsToUser(userId);

      // 4) Connecter directement l'utilisateur
      final sp = await SharedPreferences.getInstance();
      await sp.setInt('current_user_id', userId);

      // Clés cohérentes avec HomePage
      await sp.setString('user_display_name', name);
      await sp.setString('user_email', email.toLowerCase());

      // Optionnel: garder aussi l'ancienne clé
      await sp.setString('current_display_name', name);

      if (!mounted) return;

      // 5) Option A : revenir à l'écran précédent
      Navigator.pop(context, true);
    } catch (e) {
      setState(() => _message = 'Erreur lors de la création du compte.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Créer un compte')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _name,
              decoration: const InputDecoration(labelText: 'Nom complet'),
            ),
            TextField(
              controller: _email,
              decoration: const InputDecoration(labelText: 'Email'),
              keyboardType: TextInputType.emailAddress,
            ),
            TextField(
              controller: _password,
              decoration: const InputDecoration(labelText: 'Mot de passe'),
              obscureText: true,
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _signup,
              child: const Text('Créer un compte'),
            ),
            if (_message != null)
              Padding(
                padding: const EdgeInsets.only(top: 12),
                child: Text(
                  _message!,
                  style: const TextStyle(color: Colors.blue),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
