import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/app_db.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _email = TextEditingController();
  final _password = TextEditingController();
  String? _error;

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    final email = _email.text.trim();
    final password = _password.text.trim();

    if (email.isEmpty || password.isEmpty) {
      setState(() => _error = 'Veuillez remplir tous les champs.');
      return;
    }

    // 1) Chercher l'utilisateur
    final user = await AppDb.instance.getUserByEmail(email);
    if (user == null) {
      setState(() => _error = 'Utilisateur non trouvé.');
      return;
    }

    // 2) Recalculer le hash
    final storedHash = user['password_hash'] as String;
    final salt = user['salt'] as String;
    final hash = sha256.convert(utf8.encode('$salt$password')).toString();

    if (hash != storedHash) {
      setState(() => _error = 'Mot de passe incorrect.');
      return;
    }

    // 3) Sauver l'utilisateur courant dans SharedPreferences
    final sp = await SharedPreferences.getInstance();
    final userId = user['id'] as int;
    final displayName = (user['display_name'] as String?) ?? '';
    final emailLower = email.toLowerCase();

    // Identité de l'utilisateur courant
    await sp.setInt('current_user_id', userId);

    // Clés utilisées par HomePage
    await sp.setString('user_display_name', displayName);
    await sp.setString('user_email', emailLower);

    await sp.setString('current_display_name', displayName);

    // Fusionner les parties invitées (user_id NULL) avec ce compte
    await AppDb.instance.attachGuestRunsToUser(userId);

    if (!mounted) return;

    // 5) Fermer la page en renvoyant "true"
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Connexion')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _email,
              decoration: const InputDecoration(labelText: 'Email'),
              keyboardType: TextInputType.emailAddress,
            ),
            TextField(
              controller: _password,
              decoration: const InputDecoration(labelText: 'Mot de passe'),
              obscureText: true,
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _login,
              child: const Text('Se connecter'),
            ),
            if (_error != null)
              Padding(
                padding: const EdgeInsets.only(top: 12),
                child: Text(_error!, style: const TextStyle(color: Colors.red)),
              ),
          ],
        ),
      ),
    );
  }
}
