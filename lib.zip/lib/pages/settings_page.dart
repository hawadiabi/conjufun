import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../main.dart' show brandBlue, brandYellow;
import '../data/auth_repo.dart';
import '../data/sync_service.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool _syncEnabled = true;
  bool _darkModeEnabled = false;
  String? _displayName;
  String? _email;

  bool _loading = true;
  bool _syncInProgress = false;

  @override
  void initState() {
    super.initState();
    _loadPrefsAndUser();
  }

  Future<void> _loadPrefsAndUser() async {
    final prefs = await SharedPreferences.getInstance();
    final user = await AuthRepo.instance.getCurrentUser();

    if (!mounted) return;
    setState(() {
      _syncEnabled = prefs.getBool('sync_enabled') ?? true;
      _darkModeEnabled = prefs.getBool('dark_mode_enabled') ?? false;

      _displayName =
          prefs.getString('user_display_name') ??
          (user != null ? (user['display_name'] as String?) : null);

      // ✅ fallback prefs si user == null
      _email =
          prefs.getString('user_email') ??
          (user != null ? (user['email'] as String?) : null);

      _loading = false;
    });
  }

  Future<void> _onSyncChanged(bool value) async {
    setState(() => _syncEnabled = value);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('sync_enabled', value);
  }

  Future<void> _onDarkModeChanged(bool value) async {
    setState(() => _darkModeEnabled = value);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('dark_mode_enabled', value);
  }

  Future<void> _onManualSync() async {
    if (!_syncEnabled) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Active d’abord la synchronisation en ligne pour synchroniser.',
          ),
        ),
      );
      return;
    }

    setState(() => _syncInProgress = true);
    try {
      await SyncService.instance.syncCustomSetsIfEnabled();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Synchronisation terminée (si le serveur est joignable).',
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erreur pendant la synchronisation : $e')),
      );
    } finally {
      if (mounted) setState(() => _syncInProgress = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Paramètres'),
        backgroundColor: brandBlue,
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            elevation: 0,
            color: brandBlue.withOpacity(0.05),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 24,
                    backgroundColor: brandYellow.withOpacity(0.8),
                    child: Text(
                      (_displayName?.isNotEmpty == true
                              ? _displayName!.substring(0, 1)
                              : '?')
                          .toUpperCase(),
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                        color: Colors.black,
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _displayName ?? 'Utilisateur',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        if (_email != null && _email!.isNotEmpty)
                          Text(
                            _email!,
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.grey.shade700,
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 24),

          SwitchListTile(
            value: _syncEnabled,
            onChanged: _onSyncChanged,
            title: const Text(
              'Synchronisation en ligne',
              style: TextStyle(fontWeight: FontWeight.w600),
            ),
            subtitle: const Text(
              'Autoriser la sauvegarde / récupération des données lorsque tu es connecté.',
            ),
            activeColor: brandYellow,
          ),

          const Divider(height: 32),

          SwitchListTile(
            value: _darkModeEnabled,
            onChanged: _onDarkModeChanged,
            title: const Text(
              'Mode sombre (préférence)',
              style: TextStyle(fontWeight: FontWeight.w600),
            ),
            subtitle: const Text(
              'À VENIR : activera le mode sombre global de l’application.',
            ),
            activeColor: brandYellow,
          ),

          const SizedBox(height: 24),

          FilledButton.icon(
            onPressed: _syncInProgress ? null : _onManualSync,
            icon: _syncInProgress
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.sync),
            label: const Text(
              'Synchroniser maintenant',
              style: TextStyle(fontSize: 16),
            ),
          ),

          const SizedBox(height: 32),
        ],
      ),
    );
  }
}
