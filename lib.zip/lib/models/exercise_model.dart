// Ce fichier re-exporte les types définis dans exercise_vm.dart
// pour éviter la duplication de l'enum Tense et de la classe Exercise.
//
// ⚠️  Ne jamais redéfinir Tense ou Exercise ici.
//     Toujours importer depuis viewmodels/exercise_vm.dart directement.

export '../viewmodels/exercise_vm.dart' show Tense, TenseLabel, Exercise;
